import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Hero } from './components/Hero';
import { ChallengeHub } from './components/ChallengeHub';
import { IdeaLab } from './components/IdeaLab';
import { Profile } from './components/Profile';
import { AdminPanel } from './components/AdminPanel';
import { StaticPage } from './components/StaticPages';
import { Magazine } from './components/Magazine';
import { CoCreation } from './components/CoCreation';
import { SEOHandler } from './components/SEOHandler';
import { PluginInjector } from './components/PluginInjector';
import { ViewState, User, Language, SiteConfig, Article, Challenge, IdeaPost } from './types';
import { X, AlertTriangle } from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut, onAuthStateChanged, isFirebaseConfigured } from './services/firebase';

// --- DATA GENERATOR ---
const generateRealContent = (): IdeaPost[] => {
    const categories = ['فناوری', 'کشاورزی', 'پزشکی', 'هنر', 'آموزش', 'محیط زیست', 'فین‌تک', 'گردشگری', 'معماری', 'هوش مصنوعی'];
    const authors = ["علی رضایی", "سارا احمدی", "دکتر محمد کمالی", "مهندس زهرا نوری", "آرش مهدوی", "تیم نوآوران", "شرکت دانش‌بنیان افق"];
    const adjectives = ["هوشمند", "پایدار", "غیرمتمرکز", "خودکار", "بومی‌سازی شده", "ارزان", "سریع", "آموزشی", "تعاملی", "مبتنی بر بلاکچین", "سبز", "نانو"];
    const nouns = ["سامانه", "پلتفرم", "دستگاه", "اپلیکیشن", "ربات", "پهپاد", "الگوریتم", "شبکه", "مرکز", "حسگر", "بیوسنسور", "مدل زبانی"];
    
    let items: IdeaPost[] = [];
    let counter = 1;

    // 1. IDEAS (PENDAR)
    for(let i=0; i<70; i++) {
        items.push({
            id: `idea_${counter++}`,
            title: `ایده ${nouns[i%nouns.length]} ${adjectives[i%adjectives.length]}`,
            author: authors[i%authors.length],
            authorAvatar: `https://i.pravatar.cc/150?u=${counter}`,
            content: `این ایده برای حل مشکل در حوزه ${categories[i%categories.length]} طراحی شده است...`,
            category: categories[i%categories.length],
            step: 'پندار',
            likes: Math.floor(Math.random()*300),
            comments: Math.floor(Math.random()*50),
            date: '2 روز پیش',
            isFree: true,
            status: 'Approved'
        });
    }
    // 2. PLANS (GOFTAR)
    for(let i=0; i<70; i++) {
        items.push({
            id: `plan_${counter++}`,
            title: `طرح توجیهی ${nouns[i%nouns.length]} ${adjectives[i%adjectives.length]}`,
            author: authors[i%authors.length],
            authorAvatar: `https://i.pravatar.cc/150?u=${counter}`,
            content: `بیزنس پلن کامل و مستندات مالی برای...`,
            category: categories[i%categories.length],
            step: 'گفتار',
            likes: Math.floor(Math.random()*500),
            comments: Math.floor(Math.random()*80),
            date: '5 روز پیش',
            isFree: false, price: 50000000,
            hasDocuments: true,
            status: 'Approved'
        });
    }
    // 3. PROJECTS (KERDAR)
    for(let i=0; i<60; i++) {
        items.push({
            id: `proj_${counter++}`,
            title: `پروژه اجرایی ${nouns[i%nouns.length]}`,
            author: authors[i%authors.length],
            authorAvatar: `https://i.pravatar.cc/150?u=${counter}`,
            content: `محصول نهایی (MVP) آماده تست و ورود به بازار...`,
            category: categories[i%categories.length],
            step: 'کردار',
            likes: Math.floor(Math.random()*1000),
            comments: Math.floor(Math.random()*200),
            date: '1 هفته پیش',
            isFree: false, price: 250000000,
            hasDocuments: true, estimatedCost: 'Completed',
            status: 'Approved'
        });
    }
    // 4. EXPERIENCES
    for(let i=0; i<30; i++) {
        items.push({
            id: `exp_${counter++}`,
            title: `تجربه: ساخت ${nouns[i%nouns.length]} با هوش مصنوعی`,
            author: authors[i%authors.length],
            authorAvatar: `https://i.pravatar.cc/150?u=${counter}`,
            content: `من توانستم در کمتر از ۲ ساعت با استفاده از ابزارهای AI یک پلتفرم کامل بسازم...`,
            category: 'فناوری',
            step: 'تجربه',
            likes: 50, comments: 10, date: '1 روز پیش', isFree: true, status: 'Approved'
        });
    }
    return items;
};

const MOCK_USER_TEMPLATE: User = {
  id: 'temp_user',
  name: 'کاربر جدید',
  email: 'new@example.com',
  title: 'تازه وارد',
  avatar: 'https://picsum.photos/200/200?random=new',
  level: 'Egg',
  skills: [],
  bio: '',
  niki: 0,
  isAdmin: false, 
  participatingChallengeIds: [],
};

const MOCK_CHALLENGES_DATA: Challenge[] = [
  {id: '1', title: 'طراحی بسته بندی پایدار', description: 'حذف پلاستیک...', company: 'کاله', prize: '50M', deadline: '1403/08/01', category: 'Science', difficulty: 'Hard', image: 'https://picsum.photos/400/300?random=1', status: 'Approved'},
  {id: '2', title: 'لوگو فین‌تک', description: 'طراحی مینیمال...', company: 'کریپتو پی', prize: '15M', deadline: '1403/07/15', category: 'Art', difficulty: 'Medium', image: 'https://picsum.photos/400/300?random=2', status: 'Approved'}
];

const INITIAL_CONFIG: SiteConfig = {
    primaryColor: '#0052cc', 
    secondaryColor: '#ff9900',
    logoText: 'پند نیک',
    contentBgColor: '#f8fafc',
    baseFontSize: 16,
    homeTitle: 'تبدیل رویاهای خام به واقعیت‌های پول‌ساز',
    homeSubtitle: 'در پندنیک، ایده‌های شما خریدار دارند. چالش‌ها را حل کنید، طرح‌های خود را بفروشید و با کسب امتیاز "نیکی"، درآمد دلاری و ارزی داشته باشید.',
    footerText: 'اکوسیستم نوآوری باز و بین‌رشته‌ای. جایی که ایده‌های خام به واقعیت‌های پول‌ساز تبدیل می‌شوند.',
    homeConfig: { showStats: true, showTrust: true },
    challengeConfig: { showFilters: true, showPrize: true },
    ideaLabConfig: { showSteps: true, allowGuestView: false },
    profileConfig: { showChart: true, showSocial: true },
    pageLayouts: {
        home: [
            { id: 'hero', title: 'بخش اصلی', visible: true, order: 1 },
            { id: 'stats', title: 'آمار', visible: true, order: 2 },
            { id: 'lifecycle', title: 'چرخه حیات', visible: true, order: 3 },
        ],
        profile: [
            { id: 'header', title: 'هدر پروفایل', visible: true, order: 1 },
            { id: 'dna', title: 'DNA حرفه‌ای', visible: true, order: 2 },
            { id: 'experience', title: 'سوابق', visible: true, order: 3 },
        ]
    },
    plugins: [
        { id: 'seo_pack', name: 'Pandenik SEO Pack', description: 'SEO Management', version: '2.0.0', author: 'Pandenik', isActive: true, icon: 'Search' },
        { id: 'analytics', name: 'Google Analytics', description: 'Tracking', version: '3.4.1', author: 'Google', isActive: true, icon: 'BarChart' }
    ]
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => JSON.parse(localStorage.getItem('pandenik_config') || JSON.stringify(INITIAL_CONFIG)));
  const [language, setLanguage] = useState<Language>('fa');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [firebaseError, setFirebaseError] = useState('');

  const [allIdeas, setAllIdeas] = useState<IdeaPost[]>(() => generateRealContent());
  const [allChallenges, setAllChallenges] = useState<Challenge[]>(MOCK_CHALLENGES_DATA);

  useEffect(() => {
    if (isFirebaseConfigured() && auth) {
        onAuthStateChanged(auth, (u: any) => {
            if (u) setUser({...MOCK_USER_TEMPLATE, id: u.uid, name: u.displayName||'User', email: u.email||'', avatar: u.photoURL||'', ...JSON.parse(localStorage.getItem(`user_details_${u.uid}`)||'{}')});
            else setUser(null);
            setIsLoadingAuth(false);
        });
    } else setIsLoadingAuth(false);
  }, []);

  useEffect(() => localStorage.setItem('pandenik_config', JSON.stringify(siteConfig)), [siteConfig]);

  const handleUpdateUser = (u: User) => { setUser(u); localStorage.setItem(`user_details_${u.id}`, JSON.stringify(u)); };
  const handleLogout = async () => { if (isFirebaseConfigured()) await signOut(auth); setUser(null); setCurrentView(ViewState.HOME); };

  const renderContent = () => {
    switch (currentView) {
      case ViewState.HOME:
        return <Hero onCtaClick={setCurrentView} config={siteConfig} />;
      case ViewState.CHALLENGES:
        return <ChallengeHub config={siteConfig} participatingIds={user?.participatingChallengeIds || []} onToggleParticipation={() => {}} />;
      
      // --- HERE IS THE FIX: ADDING THE MISSING CASES ---
      case ViewState.IDEA_LAB:
        return <IdeaLab isLoggedIn={!!user} onLoginReq={() => setShowAuthModal(true)} config={siteConfig} externalFeed={allIdeas} setExternalFeed={setAllIdeas} forcedStep="پندار" />;
      case ViewState.GOFTAR: // Plans
         return <IdeaLab isLoggedIn={!!user} onLoginReq={() => setShowAuthModal(true)} config={siteConfig} externalFeed={allIdeas} setExternalFeed={setAllIdeas} forcedStep="گفتار" />;
      case ViewState.KERDAR: // Projects
         return <IdeaLab isLoggedIn={!!user} onLoginReq={() => setShowAuthModal(true)} config={siteConfig} externalFeed={allIdeas} setExternalFeed={setAllIdeas} forcedStep="کردار" />;
      case ViewState.EXPERIENCE: // Experiences
         return <IdeaLab isLoggedIn={!!user} onLoginReq={() => setShowAuthModal(true)} config={siteConfig} externalFeed={allIdeas} setExternalFeed={setAllIdeas} forcedStep="تجربه" />;
      case ViewState.CO_CREATION: // Co-Creation
        return <CoCreation config={siteConfig} />;
      // -----------------------------------------------

      case ViewState.PROFILE:
        return user ? <Profile user={user} config={siteConfig} onUpdateUser={handleUpdateUser} onLogout={handleLogout}/> : <Hero onCtaClick={setCurrentView} config={siteConfig}/>;
      case ViewState.ADMIN_PANEL:
        return (user?.isAdmin || user?.role === 'admin') ? <AdminPanel currentConfig={siteConfig} onUpdateConfig={setSiteConfig} allChallenges={allChallenges} setAllChallenges={setAllChallenges} allIdeas={allIdeas} setAllIdeas={setAllIdeas}/> : <div>Restricted</div>;
      case ViewState.ARTICLES:
          return <Magazine articles={[]} onBack={() => setCurrentView(ViewState.HOME)} />;
      default:
          return <StaticPage view={currentView} />;
    }
  };

  if (isLoadingAuth) return <div>Loading...</div>;

  return (
    <>
      <SEOHandler currentView={currentView} siteConfig={siteConfig} />
      <PluginInjector config={siteConfig} />
      <Layout currentView={currentView} setCurrentView={setCurrentView} user={user} language={language} setLanguage={setLanguage} onLoginClick={() => setShowAuthModal(true)} siteConfig={siteConfig}>
        {!isFirebaseConfigured() && <div className="fixed bottom-0 left-0 w-full bg-red-600 text-white text-center text-sm py-2 z-[100]">Firebase Config Missing. <button onClick={()=>setUser({...MOCK_USER_TEMPLATE, isAdmin:true, role:'admin'})} className="font-bold underline ml-2">Mock Login</button></div>}
        {renderContent()}
      </Layout>
      {showAuthModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"><div className="bg-white p-8 rounded-xl"><h2 className="text-2xl font-bold mb-4">ورود</h2><button onClick={()=>signInWithPopup(auth, googleProvider).then(()=>setShowAuthModal(false))} className="border p-2 rounded w-full">Google Login</button><button onClick={()=>setShowAuthModal(false)} className="mt-4 text-red-500">Close</button></div></div>}
    </>
  );
};

export default App;