export enum ViewState {
  HOME = 'HOME',
  CHALLENGES = 'CHALLENGES',
  PROFILE = 'PROFILE',
  IDEA_LAB = 'IDEA_LAB', // Pendar
  GOFTAR = 'GOFTAR',     // Plans
  KERDAR = 'KERDAR',     // Projects
  EXPERIENCE = 'EXPERIENCE', // New: Experiences
  CO_CREATION = 'CO_CREATION',
  CREATE_CHALLENGE = 'CREATE_CHALLENGE',
  ABOUT_US = 'ABOUT_US',
  CONTACT_US = 'CONTACT_US',
  ARTICLES = 'ARTICLES',
  ADMIN_PANEL = 'ADMIN_PANEL',
  RULES = 'RULES',
  SECURE_PAYMENT = 'SECURE_PAYMENT'
}

export type Language = 'fa' | 'en' | 'ar';

export interface Plugin {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  isActive: boolean;
  icon: string; 
  settings?: {
      scriptId?: string;
      customCode?: string;
  };
}

export interface PageSection {
    id: string;
    title: string;
    visible: boolean;
    order: number;
    backgroundColor?: string;
    textColor?: string;
}

export interface PageLayouts {
    home: PageSection[];
    profile: PageSection[];
}

export interface SiteConfig {
  primaryColor: string;
  secondaryColor?: string;
  logoText: string;
  contentBgColor: string;
  baseFontSize: number;
  borderRadius?: 'none' | 'sm' | 'md' | 'lg' | 'full';
  uiStyle?: 'minimal' | 'flat' | 'glass';
  direction?: 'rtl' | 'ltr';
  
  homeTitle?: string;
  homeSubtitle?: string;
  footerText?: string;
  
  homeConfig?: { showStats: boolean; showTrust: boolean };
  challengeConfig?: { showFilters: boolean; showPrize: boolean };
  ideaLabConfig?: { showSteps: boolean; allowGuestView: boolean };
  profileConfig?: { showChart: boolean; showSocial: boolean };

  pageLayouts?: PageLayouts;

  servicesConfig?: {
      smsProvider?: string;
      smsApiKey?: string;
      emailHost?: string;
      emailPort?: string;
      emailUser?: string;
      emailPass?: string;
  };

  securityConfig?: {
      minPasswordLength?: number;
      enable2FA?: boolean;
      maxLoginAttempts?: number;
      captchaEnabled?: boolean;
  };

  visualConfig?: {
      heroImage?: string;
      cardShadow?: 'none' | 'sm' | 'md' | 'lg';
      glassEffect?: boolean;
  };

  plugins: Plugin[];
}

export interface Role {
  id: string;
  name: string;
  permissions: {
    manageUsers: boolean;
    manageContent: boolean;
    manageSettings: boolean;
    manageRoles: boolean;
    viewReports: boolean;
  };
}

export interface WalletTransaction {
    id: string;
    title: string;
    amount: number;
    date: string;
    type: 'deposit' | 'withdraw' | 'income' | 'expense' | 'exchange';
    status: 'pending' | 'completed' | 'failed';
    method?: string;
}

export interface User {
  id: string;
  name: string;
  email?: string;
  phoneNumber?: string;
  title: string;
  avatar: string;
  level: 'Egg' | 'Larva' | 'Pupa' | 'Butterfly';
  skills: { name: string; score: number; icon?: string }[];
  bio: string;
  niki: number;
  walletHistory?: WalletTransaction[];
  isAdmin?: boolean;
  role?: string;
  participatingChallengeIds?: string[];
  
  age?: number;
  gender?: 'Male' | 'Female' | 'Other';
  education?: { degree: string; field: string; university: string; year: string; logo?: string }[];
  certificates?: { title: string; issuer: string; year: string }[];
  experiences?: { role: string; company: string; duration: string }[];
  
  // New field for Special Experiences
  specialExperiences?: { title: string; description: string; date: string; tags: string[] }[];
  
  interests?: string[];
  socialLinks?: {
    github?: string;
    gitlab?: string;
    linkedin?: string;
    website?: string;
  };

  investmentInterest?: {
    types: string[];
    budgetRange?: string;
    preferredSectors?: string[];
  };

  portfolio?: {
      id: string;
      title: string;
      image: string;
      link?: string;
  }[];
}

export interface Comment {
    id: string;
    author: string;
    avatar: string;
    text: string;
    date: string;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  fullDescription?: string;
  company: string;
  prize: string;
  deadline: string;
  category: 'Technology' | 'Art' | 'Business' | 'Science' | 'Social' | 'Other';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  image: string;
  participantsCount?: number;
  comments?: Comment[];
  status?: string;
}

export interface IdeaPost {
  id: string;
  title: string;
  author: string;
  authorAvatar: string;
  content: string; 
  privateContent?: string; 
  category: string;
  step: string; 
  likes: number;
  comments: number;
  date: string;
  
  price?: number; 
  isFree: boolean;
  estimatedCost?: string;
  hasDocuments?: boolean;
  
  images?: string[];
  tags?: string[];
  links?: {
      repo?: string;
      video?: string;
  };
  status?: string;
}

export interface Article {
    id: string;
    title: string;
    excerpt: string;
    content: string;
    author: string;
    date: string;
    image: string;
    category: string;
    status: 'Draft' | 'Published';
}

export interface Notification {
    id: string;
    type: 'info' | 'success' | 'warning';
    message: string;
    date: string;
    read: boolean;
}