
import React, { useState } from 'react';
import { User, SiteConfig } from '../types';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Share2, Download, Briefcase, User as UserIcon, BookOpen, Heart, Calendar, Github, Linkedin, Gitlab, LogOut, Edit, Save, X, Wallet, TrendingUp, DollarSign, Plus, Trash2, Zap, Gem } from 'lucide-react';

interface ProfileProps {
  user: User;
  config?: SiteConfig;
  onUpdateUser?: (updatedUser: User) => void;
  onLogout?: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, config, onUpdateUser, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'wallet'>('overview');
  const [isEditing, setIsEditing] = useState(false);
  
  // Local state for basic info
  const [editName, setEditName] = useState(user.name);
  const [editTitle, setEditTitle] = useState(user.title);
  const [editBio, setEditBio] = useState(user.bio);
  const [editGithub, setEditGithub] = useState(user.socialLinks?.github || '');
  const [editLinkedin, setEditLinkedin] = useState(user.socialLinks?.linkedin || '');

  // Local state for complex fields
  const [editSkills, setEditSkills] = useState(user.skills);
  const [editInterests, setEditInterests] = useState(user.interests || []);
  const [newInterest, setNewInterest] = useState('');
  const [editExperience, setEditExperience] = useState(user.experiences || []);
  const [editEducation, setEditEducation] = useState(user.education || []);

  const chartData = (isEditing ? editSkills : user.skills).map(s => ({ subject: s.name, A: s.score, fullMark: 100 }));

  // --- Handlers for Skills ---
  const handleSkillChange = (index: number, val: number) => {
      const newSkills = [...editSkills];
      newSkills[index].score = val;
      setEditSkills(newSkills);
  };
  const addSkill = () => {
      setEditSkills([...editSkills, { name: 'مهارت جدید', score: 50 }]);
  };
  const removeSkill = (index: number) => {
      setEditSkills(editSkills.filter((_, i) => i !== index));
  };

  // --- Handlers for Interests ---
  const addInterest = () => {
      if(newInterest.trim()) {
          setEditInterests([...editInterests, newInterest.trim()]);
          setNewInterest('');
      }
  };
  const removeInterest = (idx: number) => {
      setEditInterests(editInterests.filter((_, i) => i !== idx));
  };

  // --- Handlers for Experience ---
  const addExperience = () => {
      setEditExperience([...editExperience, { role: 'عنوان شغلی', company: 'نام شرکت', duration: 'مدت زمان' }]);
  };
  const removeExperience = (idx: number) => {
      setEditExperience(editExperience.filter((_, i) => i !== idx));
  };
  const updateExperience = (idx: number, field: string, value: string) => {
      const newExp = [...editExperience];
      // @ts-ignore
      newExp[idx][field] = value;
      setEditExperience(newExp);
  };

  // --- Handlers for Education ---
  const addEducation = () => {
      setEditEducation([...editEducation, { degree: 'مقطع', field: 'رشته', university: 'دانشگاه', year: 'سال' }]);
  };
  const removeEducation = (idx: number) => {
      setEditEducation(editEducation.filter((_, i) => i !== idx));
  };
  const updateEducation = (idx: number, field: string, value: string) => {
      const newEdu = [...editEducation];
      // @ts-ignore
      newEdu[idx][field] = value;
      setEditEducation(newEdu);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `پروفایل ${user.name} در پندنیک`,
        text: `رزومه حرفه‌ای و ایده‌های ${user.name} را در پندنیک ببینید.`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      alert('لینک پروفایل کپی شد: ' + window.location.href);
    }
  };

  const handleSave = () => {
      if (onUpdateUser) {
          onUpdateUser({
              ...user,
              name: editName,
              title: editTitle,
              bio: editBio,
              socialLinks: { ...user.socialLinks, github: editGithub, linkedin: editLinkedin },
              skills: editSkills,
              interests: editInterests,
              experiences: editExperience,
              education: editEducation
          });
      }
      setIsEditing(false);
  };

  const handleCancel = () => {
      // Revert all edits
      setEditName(user.name);
      setEditTitle(user.title);
      setEditBio(user.bio);
      setEditGithub(user.socialLinks?.github || '');
      setEditLinkedin(user.socialLinks?.linkedin || '');
      setEditSkills(user.skills);
      setEditInterests(user.interests || []);
      setEditExperience(user.experiences || []);
      setEditEducation(user.education || []);
      setIsEditing(false);
  }

  const getDevIcon = (name: string) => {
    const iconName = name.toLowerCase().replace('.', '').replace(' ', '');
    const map: {[key:string]: string} = {
        'react': 'react/react-original',
        'typescript': 'typescript/typescript-original',
        'python': 'python/python-original',
        'nodejs': 'nodejs/nodejs-original',
        'figma': 'figma/figma-original',
        'javascript': 'javascript/javascript-original',
    };
    const path = map[iconName] || `${iconName}/${iconName}-original`;
    return `https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/${path}.svg`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-fade-in">
      
      {/* Tab Navigation */}
      <div className="flex justify-center mb-8">
          <div className="bg-white p-1 rounded-xl shadow-sm border inline-flex">
              <button 
                onClick={() => setActiveTab('overview')}
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'overview' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                  <UserIcon size={18} />
                  پروفایل من
              </button>
              <button 
                onClick={() => setActiveTab('wallet')}
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'wallet' ? 'bg-amber-500 text-white shadow-md' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                  <Wallet size={18} />
                  کیف پول نیکی
              </button>
          </div>
      </div>

      {activeTab === 'overview' ? (
        <>
            {/* Header Card */}
            <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden mb-8 relative">
                <div className="h-40 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
                
                {/* Edit Controls */}
                <div className="absolute top-6 left-6 flex gap-3 z-10">
                    {isEditing ? (
                        <div className="flex gap-2">
                            <button onClick={handleSave} className="bg-green-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-600 shadow-lg font-bold text-sm">
                                <Save size={16} /> ذخیره تغییرات
                            </button>
                            <button onClick={handleCancel} className="bg-white/20 backdrop-blur text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-white/30 font-bold text-sm">
                                <X size={16} /> انصراف
                            </button>
                        </div>
                    ) : (
                        <div className="flex gap-2">
                             {user.socialLinks?.github && (
                                <a href={user.socialLinks.github} target="_blank" rel="noreferrer" className="bg-white/20 hover:bg-white/30 p-2 rounded-full backdrop-blur-sm text-white transition-all">
                                    <Github size={20} />
                                </a>
                            )}
                            {user.socialLinks?.linkedin && (
                                <a href={user.socialLinks.linkedin} target="_blank" rel="noreferrer" className="bg-white/20 hover:bg-white/30 p-2 rounded-full backdrop-blur-sm text-white transition-all">
                                    <Linkedin size={20} />
                                </a>
                            )}
                        </div>
                    )}
                </div>

                <div className="px-8 pb-8">
                <div className="relative flex flex-col md:flex-row justify-between items-end -mt-16 mb-6 gap-4">
                    <div className="flex items-end gap-6 w-full md:w-auto">
                        <div className="relative group cursor-pointer">
                            <img src={user.avatar} className="w-36 h-36 rounded-3xl border-4 border-white shadow-lg object-cover bg-white" alt={user.name} />
                            <div className="absolute -bottom-2 -right-2 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-full shadow border-2 border-white flex items-center gap-1">
                                {user.level}
                            </div>
                        </div>
                        <div className="pb-2 flex-1 min-w-[200px]">
                        {isEditing ? (
                            <div className="space-y-2 mt-4 md:mt-0">
                                <input 
                                        className="text-2xl font-bold text-gray-900 border-b-2 border-indigo-200 focus:border-indigo-600 outline-none bg-transparent w-full transition-colors pb-1"
                                        value={editName}
                                        onChange={e => setEditName(e.target.value)}
                                        placeholder="نام و نام خانوادگی"
                                />
                                <input 
                                        className="text-indigo-600 font-medium border-b border-gray-300 focus:border-indigo-500 outline-none bg-transparent w-full text-sm pb-1"
                                        value={editTitle}
                                        onChange={e => setEditTitle(e.target.value)}
                                        placeholder="عنوان شغلی"
                                />
                            </div>
                        ) : (
                            <>
                                <h1 className="text-3xl font-bold text-gray-900 mb-1">{user.name}</h1>
                                <p className="text-indigo-600 font-medium flex items-center gap-1">
                                    <Briefcase size={16} /> {user.title}
                                </p>
                            </>
                        )}
                        </div>
                    </div>
                    
                    <div className="flex gap-3 pb-2 w-full md:w-auto flex-wrap">
                        {!isEditing && (
                            <button 
                                onClick={() => setIsEditing(true)}
                                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-xl hover:bg-indigo-100 font-medium transition-colors"
                            >
                                <Edit size={18} /> ویرایش کامل پروفایل
                            </button>
                        )}
                        <button 
                            onClick={handleShare}
                            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 bg-gray-900 text-white rounded-xl hover:bg-gray-800 font-medium shadow-lg shadow-gray-200 transition-all"
                        >
                            <Share2 size={18} /> اشتراک
                        </button>
                        {onLogout && (
                            <button 
                                onClick={onLogout}
                                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 font-medium transition-colors"
                            >
                                <LogOut size={18} /> خروج
                            </button>
                        )}
                    </div>
                </div>
                
                <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-1">
                        {isEditing ? (
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-4">
                                <label className="block text-xs font-bold text-gray-500 mb-1">درباره من (بیوگرافی)</label>
                                <textarea 
                                    className="w-full border rounded-lg p-3 text-gray-700 focus:ring-2 focus:ring-indigo-200 outline-none"
                                    rows={4}
                                    value={editBio}
                                    onChange={e => setEditBio(e.target.value)}
                                    placeholder="مختصری درباره خود بنویسید..."
                                />
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <input className="w-full border rounded-lg p-2 text-sm" value={editGithub} onChange={e => setEditGithub(e.target.value)} placeholder="لینک گیت‌هاب" />
                                    <input className="w-full border rounded-lg p-2 text-sm" value={editLinkedin} onChange={e => setEditLinkedin(e.target.value)} placeholder="لینک لینکدین" />
                                </div>
                            </div>
                        ) : (
                            <p className="text-gray-600 leading-relaxed mb-6 border-r-4 border-indigo-100 pr-4">
                                {user.bio || 'هنوز بیوگرافی ثبت نشده است.'}
                            </p>
                        )}
                    </div>

                    {/* Stats */}
                    <div className="flex flex-wrap gap-2 content-start">
                        {user.age && <div className="px-3 py-1.5 bg-gray-50 rounded-lg text-sm">{user.age} ساله</div>}
                        {user.gender && <div className="px-3 py-1.5 bg-gray-50 rounded-lg text-sm">{user.gender === 'Male' ? 'مرد' : 'زن'}</div>}
                    </div>
                </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left Column: DNA & Interests */}
                <div className="lg:col-span-4 space-y-8">
                    {config?.profileConfig?.showChart !== false && (
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                            <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                                <span className="w-1 h-5 bg-indigo-500 rounded-full"></span>
                                DNA حرفه‌ای
                            </h3>
                            
                            {/* DNA Chart */}
                            <div className="h-64 relative mb-6">
                                <ResponsiveContainer width="100%" height="100%">
                                    <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
                                        <PolarGrid stroke="#e5e7eb" />
                                        <PolarAngleAxis dataKey="subject" tick={{ fill: '#4b5563', fontSize: 11 }} />
                                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false}/>
                                        <Radar name="Skills" dataKey="A" stroke="#6366f1" strokeWidth={2} fill="#6366f1" fillOpacity={0.2} />
                                    </RadarChart>
                                </ResponsiveContainer>
                            </div>

                            {/* Skills List / Editor */}
                            <div className="space-y-4">
                                {isEditing ? (
                                    <>
                                        {editSkills.map((skill, idx) => (
                                            <div key={idx} className="bg-gray-50 p-3 rounded-lg border">
                                                <div className="flex justify-between mb-2">
                                                    <input 
                                                        value={skill.name} 
                                                        onChange={(e) => {
                                                            const n = [...editSkills]; n[idx].name = e.target.value; setEditSkills(n);
                                                        }}
                                                        className="bg-transparent font-bold text-sm w-2/3 outline-none"
                                                    />
                                                    <button onClick={() => removeSkill(idx)} className="text-red-400 hover:text-red-600"><Trash2 size={14}/></button>
                                                </div>
                                                <input 
                                                    type="range" min="0" max="100" 
                                                    value={skill.score} 
                                                    onChange={(e) => handleSkillChange(idx, Number(e.target.value))}
                                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                                                />
                                            </div>
                                        ))}
                                        <button onClick={addSkill} className="w-full py-2 border border-dashed border-indigo-300 text-indigo-600 rounded-lg text-sm font-bold">+ افزودن مهارت</button>
                                    </>
                                ) : (
                                    user.skills.map(skill => (
                                        <div key={skill.name} className="flex items-center gap-3">
                                            <div className="w-8 h-8 p-1.5 bg-gray-50 rounded-lg flex items-center justify-center border border-gray-100">
                                                <img src={getDevIcon(skill.icon || skill.name)} alt="" className="w-full" onError={(e) => e.currentTarget.src='https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/devicon/devicon-original.svg'}/>
                                            </div>
                                            <div className="flex-1">
                                                <div className="flex justify-between text-xs mb-1.5">
                                                    <span className="font-bold text-gray-700">{skill.name}</span>
                                                    <span className="text-gray-500">{skill.score}%</span>
                                                </div>
                                                <div className="w-full bg-gray-100 rounded-full h-1.5">
                                                    <div className="bg-indigo-500 h-1.5 rounded-full transition-all duration-1000" style={{ width: `${skill.score}%` }}></div>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    )}

                    {/* Interests */}
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                        <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                            <Heart size={18} className="text-pink-500" />
                            علاقمندی‌ها
                        </h3>
                        {isEditing ? (
                            <div className="space-y-3">
                                <div className="flex flex-wrap gap-2">
                                    {editInterests.map((int, idx) => (
                                        <span key={idx} onClick={() => removeInterest(idx)} className="bg-pink-100 text-pink-700 px-3 py-1 rounded-full text-xs cursor-pointer hover:bg-pink-200 flex items-center gap-1">
                                            {int} <X size={12}/>
                                        </span>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <input 
                                        value={newInterest} 
                                        onChange={e => setNewInterest(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && addInterest()}
                                        placeholder="تایپ کنید و اینتر بزنید..."
                                        className="flex-1 border rounded px-2 py-1 text-sm"
                                    />
                                    <button onClick={addInterest} className="bg-pink-500 text-white px-3 rounded text-sm">+</button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-wrap gap-2">
                                {(user.interests || []).map((interest, idx) => (
                                    <span key={idx} className="bg-pink-50 text-pink-700 border border-pink-100 px-3 py-1 rounded-full text-xs font-medium">
                                        {interest}
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Column: Experience & Education */}
                <div className="lg:col-span-8 space-y-8">
                    
                    {/* Work Experience */}
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
                        <h3 className="text-lg font-bold text-gray-900 mb-8 flex items-center gap-2">
                            <Briefcase className="text-indigo-500" size={20} />
                            سوابق شغلی
                        </h3>
                        <div className={`space-y-8 ${!isEditing ? 'border-r-2 border-indigo-100 pr-8 mr-2' : ''}`}>
                            {isEditing ? (
                                <>
                                    {editExperience.map((exp, idx) => (
                                        <div key={idx} className="bg-gray-50 p-4 rounded-xl border relative">
                                            <button onClick={() => removeExperience(idx)} className="absolute top-2 left-2 text-red-500"><Trash2 size={16}/></button>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <input className="border p-2 rounded" value={exp.role} onChange={e => updateExperience(idx, 'role', e.target.value)} placeholder="نقش" />
                                                <input className="border p-2 rounded" value={exp.company} onChange={e => updateExperience(idx, 'company', e.target.value)} placeholder="شرکت" />
                                                <input className="border p-2 rounded" value={exp.duration} onChange={e => updateExperience(idx, 'duration', e.target.value)} placeholder="مدت زمان" />
                                            </div>
                                        </div>
                                    ))}
                                    <button onClick={addExperience} className="w-full py-2 border border-dashed border-indigo-300 text-indigo-600 rounded-lg text-sm font-bold">+ افزودن سابقه</button>
                                </>
                            ) : (
                                (user.experiences || []).map((exp, idx) => (
                                    <div key={idx} className="relative group">
                                        <div className="absolute top-1.5 -right-[41px] w-5 h-5 bg-white rounded-full border-4 border-indigo-500 shadow-sm z-10"></div>
                                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                                            <div>
                                                <h4 className="font-bold text-gray-900 text-lg">{exp.role}</h4>
                                                <p className="text-indigo-600 font-medium">{exp.company}</p>
                                            </div>
                                            <span className="text-xs font-bold text-gray-500 bg-gray-100 px-3 py-1 rounded-full self-start">{exp.duration}</span>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    {/* Education */}
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
                        <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                            <BookOpen className="text-indigo-500" size={20} />
                            تحصیلات و مدارک
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {isEditing ? (
                                <>
                                    {editEducation.map((edu, idx) => (
                                        <div key={idx} className="bg-gray-50 p-4 rounded-xl border relative">
                                            <button onClick={() => removeEducation(idx)} className="absolute top-2 left-2 text-red-500"><Trash2 size={16}/></button>
                                            <div className="space-y-2">
                                                <input className="w-full border p-2 rounded" value={edu.field} onChange={e => updateEducation(idx, 'field', e.target.value)} placeholder="رشته تحصیلی" />
                                                <input className="w-full border p-2 rounded" value={edu.degree} onChange={e => updateEducation(idx, 'degree', e.target.value)} placeholder="مقطع" />
                                                <div className="flex gap-2">
                                                    <input className="flex-1 border p-2 rounded" value={edu.university} onChange={e => updateEducation(idx, 'university', e.target.value)} placeholder="دانشگاه" />
                                                    <input className="w-20 border p-2 rounded" value={edu.year} onChange={e => updateEducation(idx, 'year', e.target.value)} placeholder="سال" />
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                    <button onClick={addEducation} className="col-span-full py-2 border border-dashed border-indigo-300 text-indigo-600 rounded-lg text-sm font-bold">+ افزودن تحصیلات</button>
                                </>
                            ) : (
                                (user.education || []).map((edu, idx) => (
                                    <div key={idx} className="flex gap-4 p-4 rounded-xl border border-gray-50 hover:border-gray-200 hover:bg-gray-50 transition-colors">
                                        <div className="w-12 h-12 flex-shrink-0 bg-white rounded-lg p-1 border border-gray-100 flex items-center justify-center">
                                            {edu.logo ? 
                                                <img src={edu.logo} alt={edu.university} className="w-full h-full object-contain" /> :
                                                <BookOpen className="text-gray-300" />
                                            }
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-gray-900">{edu.field}</h4>
                                            <div className="text-sm text-gray-600 mt-1">{edu.degree}</div>
                                            <div className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                                                <span>{edu.university}</span>
                                                <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                                                <span>{edu.year}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
      ) : (
        <div className="max-w-4xl mx-auto animate-fade-in">
            {/* Wallet Tab */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Visual Card */}
                <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-8 text-white relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 w-40 h-40 bg-indigo-500 opacity-20 rounded-full -ml-10 -mb-10 blur-2xl"></div>
                    
                    <div className="relative z-10 flex flex-col justify-between h-full min-h-[200px]">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-gray-400 font-medium mb-1">موجودی کیف پول</h3>
                                <div className="text-4xl font-bold flex items-center gap-2">
                                    {user.niki.toLocaleString()} <span className="text-xl text-amber-400">Niki</span>
                                </div>
                            </div>
                            <Gem className="text-amber-400 w-10 h-10 animate-pulse" />
                        </div>
                        
                        <div className="mt-8 pt-6 border-t border-gray-700 flex justify-between items-end">
                            <div>
                                <p className="text-xs text-gray-400 mb-1">ارزش تخمینی (USD)</p>
                                <p className="text-xl font-mono text-green-400">${(user.niki * 0.1).toFixed(2)}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-xs text-gray-400 mb-1">سطح کاربری</p>
                                <p className="font-bold text-amber-400">{user.level}</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Actions / Info */}
                <div className="space-y-4">
                    <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                        <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2"><TrendingUp className="text-green-600"/> سرمایه‌گذاری‌های من</h3>
                        <p className="text-sm text-gray-500 mb-4">
                            شما می‌توانید نیکی‌های خود را روی ایده‌ها و طرح‌های دیگران سرمایه‌گذاری کنید و در موفقیت آن‌ها شریک شوید.
                        </p>
                        
                        {/* Mock Active Investments */}
                        <div className="space-y-3">
                            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-indigo-100 rounded flex items-center justify-center text-indigo-600"><Zap size={16}/></div>
                                    <div>
                                        <p className="text-sm font-bold">پروژه پهپاد سمپاش</p>
                                        <p className="text-xs text-gray-400">سهم شما: ۵٪</p>
                                    </div>
                                </div>
                                <span className="font-bold text-green-600 text-sm">+500 Niki</span>
                            </div>
                            <button className="w-full py-2 border border-dashed border-gray-300 rounded-lg text-xs text-gray-500 hover:bg-gray-50">
                                مشاهده فرصت‌های سرمایه‌گذاری
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Transaction History */}
            <div className="mt-8 bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <h3 className="text-lg font-bold text-gray-900 mb-6">تاریخچه تراکنش‌ها</h3>
                <div className="space-y-4">
                    {[
                        { title: 'پاداش حل چالش کاله', amount: '+5000', date: '۱۴۰۳/۰۶/۲۰', type: 'income' },
                        { title: 'سرمایه‌گذاری روی طرح تصفیه آب', amount: '-2000', date: '۱۴۰۳/۰۶/۱۸', type: 'expense' },
                        { title: 'پاداش لایک و فعالیت', amount: '+150', date: '۱۴۰۳/۰۶/۱۵', type: 'income' },
                    ].map((tx, i) => (
                        <div key={i} className="flex items-center justify-between p-4 border-b border-gray-50 last:border-0 hover:bg-gray-50 rounded-lg transition-colors">
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${tx.type === 'income' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                                    {tx.type === 'income' ? <TrendingUp size={18}/> : <DollarSign size={18}/>}
                                </div>
                                <div>
                                    <p className="font-bold text-gray-900">{tx.title}</p>
                                    <p className="text-xs text-gray-500">{tx.date}</p>
                                </div>
                            </div>
                            <span className={`font-mono font-bold ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                                {tx.amount} Niki
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
