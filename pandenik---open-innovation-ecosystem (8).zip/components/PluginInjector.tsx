
import React, { useEffect } from 'react';
import { SiteConfig } from '../types';

interface PluginInjectorProps {
  config: SiteConfig;
}

export const PluginInjector: React.FC<PluginInjectorProps> = ({ config }) => {
  
  // Handle Chat Plugin (Mocking Tawk.to or similar behavior)
  useEffect(() => {
    const chatPlugin = config.plugins.find(p => p.id === 'support_chat' && p.isActive);
    
    // Remove existing chat scripts if plugin is disabled
    if (!chatPlugin) {
        // Logic to cleanup script if possible
        return;
    }

    if (chatPlugin && chatPlugin.isActive) {
        // In a real scenario, you would inject the script tag here
        // Example:
        // const script = document.createElement("script");
        // script.src = "https://embed.tawk.to/YOUR_ID/default";
        // script.async = true;
        // document.body.appendChild(script);
        
        console.log("System: Chat Plugin is Active. Script injected.");
    }
  }, [config.plugins]);

  // Handle Analytics
  useEffect(() => {
      const analyticsPlugin = config.plugins.find(p => p.id === 'analytics' && p.isActive);
      if (analyticsPlugin && analyticsPlugin.isActive) {
          console.log("System: Analytics Tracking Initialized.");
          // In real implementation: window.dataLayer.push(...)
      }
  }, [config.plugins]);

  return null;
};
