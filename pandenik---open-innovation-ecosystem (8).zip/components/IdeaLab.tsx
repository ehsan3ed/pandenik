import React, { useState, useEffect } from 'react';
import { Lightbulb, MessageSquare, Wrench, Users, Rocket, BrainCircuit, Zap, Heart, MessageCircle, Lock, LayoutGrid, UploadCloud, Info, Image as ImageIcon, Hash, Share2, Search, Filter, PlayCircle, Github, SearchCheck, DollarSign, Eye, ArrowRight, FileText, Layers, Cpu, Palette, Briefcase, Stethoscope, Leaf, GraduationCap, Tractor, Home, HelpCircle, BookOpen } from 'lucide-react';
import { analyzeIdea } from '../services/geminiService';
import { IdeaPost, SiteConfig } from '../types';
import { auth, db } from '../services/firebase';

// Steps definition
const steps = [
  { id: 'pendar', title: 'پندار', subtitle: '(ایده)', icon: Lightbulb, description: 'ثبت جرقه اولیه ذهنی. چه چیزی در ذهن دارید؟' },
  { id: 'goftar', title: 'گفتار', subtitle: '(طرح)', icon: MessageSquare, description: 'تبدیل ایده به یک طرح منسجم. برنامه‌ریزی و ساختار شما چیست؟' },
  { id: 'kerdar', title: 'کردار', subtitle: '(پروژه)', icon: Wrench, description: 'طرح آماده اجرا یا اجرا شده. مستندات و نمونه اولیه را ارائه دهید.' },
  { id: 'tajrobeh', title: 'تجربه', subtitle: '(دانش)', icon: BookOpen, description: 'اشتراک‌گذاری تجربیات ارزشمند و مهارت‌ها.' },
  { id: 'pand', title: 'پند', subtitle: '(راه حل)', icon: BrainCircuit, description: 'درخواست راه حل و مشورت برای مشکلات خاص' },
  { id: 'co-creation', title: 'هم‌آفرینی', subtitle: '(مشارکت)', icon: Users, description: 'تشکیل تیم و جذب هم‌بنیان‌گذار' },
  { id: 'execution', title: 'اجرا', subtitle: '(تولید)', icon: Rocket, description: 'تولید نهایی و اتصال به بازار سرمایه' },
];

// Fallback Mock Data if no external feed is provided
const MOCK_IDEAS: IdeaPost[] = [
    {
        id: '1',
        title: 'سیستم آبیاری هوشمند',
        author: 'علی رضایی',
        authorAvatar: 'https://i.pravatar.cc/150?u=1',
        content: 'یک سیستم مبتنی بر IoT برای بهینه‌سازی مصرف آب در باغات پسته...',
        category: 'کشاورزی',
        step: 'پندار',
        likes: 120,
        comments: 45,
        date: '2 روز پیش',
        isFree: true
    }
];

interface IdeaLabProps {
    isLoggedIn: boolean;
    onLoginReq: () => void;
    config?: SiteConfig;
    // New props for state lifting
    externalFeed?: IdeaPost[];
    setExternalFeed?: (ideas: IdeaPost[]) => void;
    forcedStep?: 'پندار' | 'گفتار' | 'کردار' | 'تجربه'; // New Prop
}

export const IdeaLab: React.FC<IdeaLabProps> = ({ isLoggedIn, onLoginReq, config, externalFeed, setExternalFeed, forcedStep }) => {
  const [activeTab, setActiveTab] = useState<'create' | 'feed'>('feed');
  const initialStepIdx = forcedStep ? steps.findIndex(s => s.title === forcedStep) : 0;
  const [activeStep, setActiveStep] = useState(initialStepIdx !== -1 ? initialStepIdx : 0);
  const [category, setCategory] = useState('فناوری');
  const [aiFeedback, setAiFeedback] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Local state initialized with Mock, but useEffect will override it with externalFeed
  const [localFeed, setLocalFeed] = useState<IdeaPost[]>(MOCK_IDEAS);

  // Sync with parent if provided
  useEffect(() => {
    if (externalFeed && externalFeed.length > 0) {
         setLocalFeed(externalFeed);
    } else if (setExternalFeed && localFeed.length > 0 && (!externalFeed || externalFeed.length === 0)) {
         // Initial load: push mocks up to App if app is empty
         setExternalFeed(MOCK_IDEAS);
    }
  }, [externalFeed]);

  const updateFeed = (newFeed: IdeaPost[]) => {
    setLocalFeed(newFeed);
    if (setExternalFeed) setExternalFeed(newFeed);
  }

  // Interaction States
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  
  // Form State
  const [title, setTitle] = useState('');
  const [publicDesc, setPublicDesc] = useState('');
  const [privateDesc, setPrivateDesc] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('');
  const [isFree, setIsFree] = useState(true);
  const [price, setPrice] = useState('');
  const [tags, setTags] = useState('');
  const [repoLink, setRepoLink] = useState('');
  const [videoLink, setVideoLink] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterStep, setFilterStep] = useState(forcedStep || 'All');
  
  const isSeoPluginActive = config?.plugins?.find(p => p.id === 'seo_pack')?.isActive;

  const handleAnalysis = async () => {
    if (!publicDesc.trim()) return;
    setIsAnalyzing(true);
    setAiFeedback(null);
    const feedback = await analyzeIdea(publicDesc, category);
    setAiFeedback(feedback);
    setIsAnalyzing(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          setUploadedImage(URL.createObjectURL(e.target.files[0]));
      }
  };

  const handleSubmit = () => {
      if (!isLoggedIn) {
          onLoginReq();
          return;
      }
      if (!title || !publicDesc) {
          alert("عنوان و توضیحات الزامی هستند.");
          return;
      }

      const finalStep = forcedStep || steps[activeStep].title;

      const newIdea: IdeaPost = {
          id: Date.now().toString(),
          title: title,
          author: auth.currentUser?.displayName || 'کاربر ناشناس', 
          authorAvatar: auth.currentUser?.photoURL || 'https://i.pravatar.cc/150?u=me',
          content: publicDesc,
          privateContent: privateDesc,
          category,
          step: finalStep,
          likes: 0,
          comments: 0,
          date: 'همین الان',
          isFree,
          price: price ? parseInt(price) : 0,
          estimatedCost,
          tags: tags.split(' ').filter(t => t.startsWith('#')),
          links: { repo: repoLink, video: videoLink },
          images: uploadedImage ? [uploadedImage] : [],
          hasDocuments: activeStep > 0
      };
      
      updateFeed([newIdea, ...localFeed]);
      setActiveTab('feed');
      
      // Reset
      setTitle('');
      setPublicDesc('');
      setPrivateDesc('');
      setPrice('');
      setTags('');
      setUploadedImage(null);
      alert("آیتم شما با موفقیت ثبت شد.");
  };

  const toggleLike = (id: string) => {
      if (!isLoggedIn) {
          onLoginReq();
          return;
      }
      const newLikes = new Set(likedPosts);
      if (newLikes.has(id)) {
          newLikes.delete(id);
      } else {
          newLikes.add(id);
      }
      setLikedPosts(newLikes);
  };

  const filteredFeed = localFeed.filter(post => {
      const matchSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || post.content.includes(searchTerm);
      const matchCat = filterCategory === 'All' || post.category === filterCategory;
      const matchStep = forcedStep ? post.step === forcedStep : (filterStep === 'All' || post.step === filterStep);
      return matchSearch && matchCat && matchStep;
  });

  const getPageTitle = () => {
      if (forcedStep === 'پندار') return 'مرکز ایده‌پردازی';
      if (forcedStep === 'گفتار') return 'بانک طرح‌های توجیهی';
      if (forcedStep === 'کردار') return 'پروژه‌های اجرایی';
      if (forcedStep === 'تجربه') return 'بانک تجربیات ارزشمند';
      return config?.ideaLabConfig?.showSteps === false ? "ایده‌ها" : "مرکز نوآوری پندنیک";
  }

  const getPageDesc = () => {
      if (forcedStep === 'تجربه') return 'تجربیات خود را به اشتراک بگذارید و از مسیر دیگران بیاموزید.';
      return 'از پندار تا کردار؛ مسیر خلق ارزش';
  }

  // Category Icon Mapping
  const getCategoryIcon = (cat: string) => {
      switch(cat) {
          case 'فناوری': return <Cpu size={14} />;
          case 'هنر': return <Palette size={14} />;
          case 'کسب‌وکار': return <Briefcase size={14} />;
          case 'پزشکی': return <Stethoscope size={14} />;
          case 'محیط زیست': return <Leaf size={14} />;
          case 'آموزش': return <GraduationCap size={14} />;
          case 'کشاورزی': return <Tractor size={14} />;
          case 'معماری': return <Home size={14} />;
          default: return <HelpCircle size={14} />;
      }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            {getPageTitle()}
        </h2>
        <p className="mt-4 text-xl text-gray-500">{getPageDesc()}</p>
      </div>

      <div className="flex justify-center mb-8">
          <div className="bg-white p-1 rounded-xl shadow-sm border inline-flex sticky top-20 z-40">
              <button 
                onClick={() => setActiveTab('create')}
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'create' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                  <Lightbulb size={18} />
                  ثبت {forcedStep || 'مورد'} جدید
              </button>
              <button 
                onClick={() => setActiveTab('feed')}
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'feed' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                  <LayoutGrid size={18} />
                  مشاهده {forcedStep ? (forcedStep === 'تجربه' ? 'تجربیات' : forcedStep === 'پندار' ? 'ایده‌ها' : forcedStep === 'گفتار' ? 'طرح‌ها' : 'پروژه‌ها') : 'همه موارد'}
              </button>
          </div>
      </div>

      {activeTab === 'create' ? (
          // Create Form
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8 animate-fade-in">
                {!isLoggedIn && (
                     <div className="bg-yellow-50 border-r-4 border-yellow-400 p-4 mb-6 rounded text-yellow-800 flex items-center gap-2">
                        <Info size={20}/>
                        <span>برای ثبت نهایی و کسب امتیاز نیکی، لطفاً وارد حساب خود شوید.</span>
                        <button onClick={onLoginReq} className="underline font-bold">ورود</button>
                     </div>
                )}
                
                {/* Steps Selector - Only show if NO forced step, OR show simplified visual */}
                {!forcedStep ? (
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-8">
                        {steps.map((step, idx) => {
                            const Icon = step.icon;
                            const isActive = activeStep === idx;
                            return (
                                <button key={step.id} onClick={() => setActiveStep(idx)} className={`flex flex-col items-center p-2 rounded-lg border transition-all ${isActive ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-gray-50 border-transparent text-gray-500'}`}>
                                    <Icon size={20} className="mb-1"/>
                                    <span className="text-xs font-bold">{step.title}</span>
                                    <span className="text-[10px] text-gray-400">{step.subtitle}</span>
                                </button>
                            )
                        })}
                    </div>
                ) : (
                    <div className="mb-8 p-4 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center gap-3">
                        <Info className="text-indigo-600"/>
                        <p className="text-sm text-indigo-800">
                            شما در حال ثبت یک <strong>{forcedStep}</strong> هستید. لطفاً اطلاعات دقیق و مرتبط وارد کنید.
                        </p>
                    </div>
                )}

                {/* Form Fields */}
                <div className="space-y-6 max-w-3xl mx-auto">
                    <div>
                        <label className="block text-sm font-medium mb-1">عنوان {forcedStep || steps[activeStep].subtitle}</label>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-200 outline-none" placeholder={activeStep === 0 ? "مثلاً: سیستم تصفیه آب خورشیدی..." : "مثلاً: طرح تجاری (BP) پلتفرم گردشگری..."} />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                             <label className="block text-sm font-medium mb-1">دسته‌بندی</label>
                             <select value={category} onChange={e => setCategory(e.target.value)} className="w-full border rounded-lg px-4 py-2 bg-white">
                                 <option>فناوری</option>
                                 <option>هنر</option>
                                 <option>کسب‌وکار</option>
                                 <option>پزشکی</option>
                                 <option>محیط زیست</option>
                                 <option>آموزش</option>
                                 <option>کشاورزی</option>
                                 <option>معماری</option>
                                 <option>سایر</option>
                             </select>
                        </div>
                        <div>
                             <label className="block text-sm font-medium mb-1">هشتگ‌ها</label>
                             <div className="relative">
                                 <Hash className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                                 <input type="text" value={tags} onChange={e => setTags(e.target.value)} className="w-full border rounded-lg pr-9 pl-3 py-2" placeholder="#هوش_مصنوعی #استارتاپ" />
                             </div>
                             {isSeoPluginActive && <p className="text-xs text-green-600 mt-1 flex items-center gap-1"><SearchCheck size={12}/> آنالیزور سئو: کلمات کلیدی مناسب استفاده کنید.</p>}
                        </div>
                    </div>

                    {/* Image Upload */}
                    <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer relative">
                        <input type="file" onChange={handleImageUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*" />
                        {uploadedImage ? (
                            <img src={uploadedImage} alt="Preview" className="mx-auto h-40 object-contain rounded" />
                        ) : (
                            <div className="flex flex-col items-center text-gray-500">
                                <UploadCloud size={32} className="mb-2" />
                                <span className="text-sm font-medium">آپلود تصویر / مستندات</span>
                                <span className="text-xs text-gray-400 mt-1">PNG, JPG تا ۵ مگابایت</span>
                            </div>
                        )}
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-1">
                            <label className="block text-sm font-medium">توضیحات عمومی (خلاصه مدیریتی)</label>
                            <button onClick={handleAnalysis} disabled={isAnalyzing} className="text-xs bg-indigo-50 text-indigo-700 px-2 py-1 rounded flex items-center gap-1 hover:bg-indigo-100">
                                {isAnalyzing ? 'در حال تحلیل...' : <><Zap size={12}/> تحلیل هوشمند AI</>}
                            </button>
                        </div>
                        <textarea rows={5} value={publicDesc} onChange={e => setPublicDesc(e.target.value)} className="w-full border rounded-lg px-4 py-2" placeholder="شرح کاملی از آنچه در ذهن دارید یا طراحی کرده‌اید..."></textarea>
                        {aiFeedback && (
                            <div className="mt-2 bg-indigo-50 border border-indigo-100 p-3 rounded-lg text-sm text-indigo-800 flex gap-2 items-start">
                                <BrainCircuit className="flex-shrink-0 mt-1" size={16} />
                                <p>{aiFeedback}</p>
                            </div>
                        )}
                    </div>

                    {(forcedStep === 'گفتار' || forcedStep === 'کردار' || activeStep > 0) && (
                        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                            <div className="flex items-center gap-2 mb-4 text-gray-800 font-bold">
                                <Lock size={16} />
                                <span>اطلاعات تکمیلی و محرمانه (برای طرح و پروژه)</span>
                            </div>
                            <textarea rows={3} value={privateDesc} onChange={e => setPrivateDesc(e.target.value)} className="w-full border rounded-lg px-4 py-2 mb-4" placeholder="جزئیات فنی، بیزنس پلن، یا تحلیل بازار که فقط خریداران یا سرمایه‌گذاران ببینند..."></textarea>
                            
                            <div className="flex items-center gap-4 mb-4">
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" checked={isFree} onChange={() => setIsFree(true)} className="text-indigo-600" />
                                    <span className="text-sm">رایگان / عمومی</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" checked={!isFree} onChange={() => setIsFree(false)} className="text-indigo-600" />
                                    <span className="text-sm">فروشی / جذب سرمایه</span>
                                </label>
                            </div>

                            {!isFree && (
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-medium mb-1">قیمت فروش طرح / ارزش‌گذاری</label>
                                        <div className="relative">
                                            <DollarSign className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                                            <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full border rounded pr-8 pl-2 py-2 text-sm" placeholder="به تومان" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium mb-1">برآورد هزینه اجرا</label>
                                        <input type="text" value={estimatedCost} onChange={e => setEstimatedCost(e.target.value)} className="w-full border rounded px-3 py-2 text-sm" placeholder="مثلاً: ۵۰۰ میلیون تومان" />
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="relative">
                            <Github className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                            <input type="text" value={repoLink} onChange={e => setRepoLink(e.target.value)} className="w-full border rounded pr-9 pl-3 py-2 text-sm" placeholder="لینک گیت‌هاب / گیت‌لب (اختیاری)" />
                        </div>
                         <div className="relative">
                            <PlayCircle className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                            <input type="text" value={videoLink} onChange={e => setVideoLink(e.target.value)} className="w-full border rounded pr-9 pl-3 py-2 text-sm" placeholder="لینک ویدیو معرفی (یوتیوب/آپارات)" />
                        </div>
                    </div>

                    <button onClick={handleSubmit} className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-xl font-bold hover:shadow-lg transition-all transform hover:-translate-y-1">
                        ثبت نهایی و انتشار
                    </button>
                    <p className="text-center text-xs text-gray-500 mt-2">با ثبت این مورد، قوانین مالکیت معنوی و شرایط پندنیک را می‌پذیرم.</p>
                </div>
          </div>
      ) : (
          // Feed View
          <div className="max-w-6xl mx-auto">
              {/* Search & Filters */}
              <div className="mb-6 bg-white p-4 rounded-xl shadow-sm border space-y-4">
                  <div className="relative">
                      <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
                      <input type="text" placeholder="جستجو در ایده‌ها، طرح‌ها و پروژه‌ها..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full border rounded-lg pr-10 pl-4 py-2 focus:ring-2 focus:ring-indigo-100 outline-none" />
                  </div>
                  
                  <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
                      <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
                          <Filter size={20} className="text-gray-400 flex-shrink-0" />
                          <span className="text-xs font-bold text-gray-500 ml-2">دسته‌بندی:</span>
                          {['All', 'فناوری', 'هنر', 'کسب‌وکار', 'پزشکی', 'کشاورزی', 'معماری'].map(cat => (
                              <button 
                                key={cat} 
                                onClick={() => setFilterCategory(cat)}
                                className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border transition-colors flex items-center gap-1 ${filterCategory === cat ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'}`}
                              >
                                  {cat !== 'All' && getCategoryIcon(cat)}
                                  {cat === 'All' ? 'همه' : cat}
                              </button>
                          ))}
                      </div>

                       {!forcedStep && (
                           <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
                              <span className="text-xs font-bold text-gray-500 ml-2">مرحله:</span>
                              {['All', 'پندار', 'گفتار', 'کردار'].map(step => (
                                  <button 
                                    key={step} 
                                    onClick={() => setFilterStep(step)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border transition-colors ${filterStep === step ? 'bg-green-50 border-green-200 text-green-700' : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'}`}
                                  >
                                      {step === 'All' ? 'همه مراحل' : step}
                                  </button>
                              ))}
                          </div>
                       )}
                  </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredFeed.map(post => (
                  <div key={post.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all flex flex-col h-full group">
                      {/* Card Image */}
                      <div className="h-48 overflow-hidden relative bg-gray-100">
                          {post.images && post.images.length > 0 ? (
                              <img src={post.images[0]} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          ) : (
                              <div className="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50">
                                  <ImageIcon size={48} />
                              </div>
                          )}
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold text-gray-800 shadow-sm border border-gray-100 flex items-center gap-1">
                              {getCategoryIcon(post.category)}
                              {post.category}
                          </div>
                          <div className={`absolute top-3 left-3 px-2 py-1 rounded text-xs font-bold text-white shadow-sm flex items-center gap-1
                              ${post.step === 'اجرا' ? 'bg-green-500' : post.step === 'کردار' ? 'bg-blue-500' : post.step === 'گفتار' ? 'bg-indigo-500' : 'bg-amber-500'}`}>
                              {post.step === 'گفتار' && <FileText size={10} />}
                              {post.step}
                          </div>
                      </div>

                      <div className="p-5 flex-1 flex flex-col">
                          <div className="flex items-center gap-2 mb-3">
                              <img src={post.authorAvatar} alt={post.author} className="w-6 h-6 rounded-full border border-gray-200" />
                              <span className="text-xs text-gray-500 truncate">{post.author}</span>
                              <span className="text-xs text-gray-300">•</span>
                              <span className="text-xs text-gray-400">{post.date}</span>
                          </div>

                          <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors cursor-pointer">{post.title}</h3>
                          <p className="text-gray-500 text-sm mb-4 line-clamp-3 leading-relaxed flex-1">{post.content}</p>

                          {/* Plan/Project specifics */}
                          {post.step !== 'پندار' && (
                              <div className="grid grid-cols-2 gap-2 mb-4 bg-gray-50 p-2 rounded-lg border border-gray-100">
                                  <div className="text-xs text-gray-500 text-center border-l border-gray-200">
                                      <span className="block font-bold text-gray-700">{post.hasDocuments ? 'دارد' : 'ندارد'}</span>
                                      مستندات
                                  </div>
                                  <div className="text-xs text-gray-500 text-center">
                                      <span className="block font-bold text-gray-700">{post.estimatedCost}</span>
                                      هزینه اجرا
                                  </div>
                              </div>
                          )}

                          {/* Tags */}
                          <div className="flex flex-wrap gap-1 mb-4">
                              {post.tags?.slice(0, 3).map(tag => (
                                  <span key={tag} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-1 rounded border border-gray-200">#{tag.replace('#','')}</span>
                              ))}
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t border-gray-50 mt-auto">
                              <div className="flex gap-4">
                                  <button 
                                    onClick={() => toggleLike(post.id)}
                                    className={`flex items-center gap-1 text-sm transition-colors ${likedPosts.has(post.id) ? 'text-red-500 font-bold' : 'text-gray-400 hover:text-red-500'}`}
                                  >
                                      <Heart size={16} fill={likedPosts.has(post.id) ? "currentColor" : "none"} />
                                      {post.likes + (likedPosts.has(post.id) ? 1 : 0)}
                                  </button>
                                  <button className="flex items-center gap-1 text-sm text-gray-400 hover:text-indigo-600 transition-colors">
                                      <MessageCircle size={16} />
                                      {post.comments}
                                  </button>
                              </div>
                              
                              <button className="text-indigo-600 font-medium text-sm flex items-center gap-1 hover:gap-2 transition-all">
                                  مشاهده جزئیات <ArrowRight size={16}/>
                              </button>
                          </div>
                      </div>
                      
                      {/* Price Tag if not free */}
                      {!post.isFree && (
                          <div className="bg-gradient-to-r from-emerald-50 to-green-50 px-5 py-3 border-t border-green-100 flex justify-between items-center">
                              <span className="text-xs font-bold text-green-700 flex items-center gap-1"><DollarSign size={14}/> {post.step === 'گفتار' ? 'قیمت طرح' : 'ارزش سهام'}</span>
                              <span className="text-sm font-bold text-green-800">{post.price?.toLocaleString()} تومان</span>
                          </div>
                      )}
                  </div>
                ))}
              </div>
              
              {filteredFeed.length === 0 && (
                  <div className="text-center py-20 bg-gray-50 rounded-xl border border-dashed">
                      <p className="text-gray-500">هیچ موردی با این مشخصات یافت نشد.</p>
                      <button onClick={() => {setSearchTerm(''); setFilterCategory('All'); setFilterStep('All')}} className="text-indigo-600 text-sm mt-2 hover:underline font-bold">پاک کردن فیلترها</button>
                  </div>
              )}
          </div>
      )}
    </div>
  );
};