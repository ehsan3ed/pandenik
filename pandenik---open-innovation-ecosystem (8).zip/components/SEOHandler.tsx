
import React, { useEffect } from 'react';
import { SiteConfig, ViewState } from '../types';

interface SEOHandlerProps {
  currentView: ViewState;
  siteConfig: SiteConfig;
}

export const SEOHandler: React.FC<SEOHandlerProps> = ({ currentView, siteConfig }) => {
  useEffect(() => {
    if (!siteConfig.plugins.find(p => p.id === 'seo_pack' && p.isActive)) return;

    let title = siteConfig.logoText;
    let desc = siteConfig.homeSubtitle || 'اکوسیستم نوآوری باز';

    switch (currentView) {
      case ViewState.HOME:
        title = `${siteConfig.homeTitle || 'خانه'} | ${siteConfig.logoText}`;
        break;
      case ViewState.CHALLENGES:
        title = `چالش‌های نوآوری | ${siteConfig.logoText}`;
        desc = 'لیست چالش‌های فعال، جایزه‌های نقدی و فرصت‌های همکاری با شرکت‌های بزرگ.';
        break;
      case ViewState.IDEA_LAB:
        title = `ثبت ایده و طرح | ${siteConfig.logoText}`;
        desc = 'ایده‌های خود را ثبت کنید، تیم بسازید و جذب سرمایه کنید.';
        break;
      case ViewState.PROFILE:
        title = `پروفایل من | ${siteConfig.logoText}`;
        break;
       case ViewState.ARTICLES:
        title = `مجله و مقالات | ${siteConfig.logoText}`;
        break;
    }

    // Actual DOM Manipulation
    document.title = title;
    
    // Update Meta Description
    let metaDesc = document.querySelector("meta[name='description']");
    if (!metaDesc) {
        metaDesc = document.createElement('meta');
        metaDesc.setAttribute('name', 'description');
        document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', desc);

  }, [currentView, siteConfig]);

  return null; // This component doesn't render UI, just handles Side Effects
};
