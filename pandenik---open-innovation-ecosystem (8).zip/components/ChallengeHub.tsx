
import React, { useState } from 'react';
import { Challenge, SiteConfig } from '../types';
import { Search, Filter, Coins, CheckCircle, Clock, Bell, BellRing } from 'lucide-react';
import { matchSkillsToChallenge } from '../services/geminiService';

const MOCK_CHALLENGES: Challenge[] = [
  {
    id: '1',
    title: 'طراحی بسته بندی پایدار برای مواد غذایی',
    description: 'ما به دنبال راهکاری برای حذف پلاستیک از بسته‌بندی محصولات لبنی خود هستیم. راهکار باید ارزان و تجزیه‌پذیر باشد.',
    company: 'کاله',
    prize: '۵۰,۰۰۰,۰۰۰ تومان',
    deadline: '۱۴۰۳/۰۸/۰۱',
    category: 'Science',
    difficulty: 'Hard',
    image: 'https://picsum.photos/400/300?random=1'
  },
  {
    id: '2',
    title: 'طراحی لوگو و هویت بصری استارتاپ فین‌تک',
    description: 'طراحی مینیمال برای یک صرافی غیرمتمرکز. نیاز به لوگو، پالت رنگی و فونت سازمانی.',
    company: 'کریپتو پی',
    prize: '۱۵,۰۰۰,۰۰۰ تومان',
    deadline: '۱۴۰۳/۰۷/۱۵',
    category: 'Art',
    difficulty: 'Medium',
    image: 'https://picsum.photos/400/300?random=2'
  },
  {
    id: '3',
    title: 'بهینه‌سازی الگوریتم مسیریابی پهپاد',
    description: 'کد پایتون برای یافتن کوتاه‌ترین مسیر در فضای سه بعدی با وجود موانع متحرک.',
    company: 'پست هوایی',
    prize: '۰.۵ بیت‌کوین',
    deadline: '۱۴۰۳/۰۹/۱۰',
    category: 'Technology',
    difficulty: 'Hard',
    image: 'https://picsum.photos/400/300?random=3'
  },
  {
    id: '4',
    title: 'کمپین تبلیغاتی ویروسی',
    description: 'ایده‌پردازی برای یک کمپین تبلیغاتی در شبکه‌های اجتماعی با هدف جذب نسل Z.',
    company: 'مدیا استار',
    prize: '۱۰,۰۰۰,۰۰۰ تومان',
    deadline: '۱۴۰۳/۰۷/۲۰',
    category: 'Business',
    difficulty: 'Easy',
    image: 'https://picsum.photos/400/300?random=4'
  }
];

interface ChallengeHubProps {
    config?: SiteConfig;
    participatingIds: string[];
    onToggleParticipation: (id: string) => void;
}

export const ChallengeHub: React.FC<ChallengeHubProps> = ({ config, participatingIds, onToggleParticipation }) => {
  const [filter, setFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [matchingScores, setMatchingScores] = useState<{[key: string]: number}>({});
  
  // Interaction States
  // participating state removed in favor of props
  const [reminders, setReminders] = useState<Set<string>>(new Set());

  const handleMatchCheck = async (challengeId: string, desc: string) => {
      // Mock user skills for demonstration
      const mySkills = ['طراحی گرافیک', 'Adobe Illustrator', 'خلاقیت'];
      setMatchingScores(prev => ({...prev, [challengeId]: -1})); // Loading state
      
      const score = await matchSkillsToChallenge(mySkills, desc);
      setMatchingScores(prev => ({...prev, [challengeId]: score}));
  }

  const toggleParticipation = (id: string) => {
      const isParticipating = participatingIds.includes(id);
      
      // Call parent handler
      onToggleParticipation(id);

      // Handle side effects (reminders)
      if (isParticipating) {
          // If leaving, remove reminder if exists
          if (reminders.has(id)) {
              const nextRem = new Set(reminders);
              nextRem.delete(id);
              setReminders(nextRem);
          }
      }
  };

  const toggleReminder = (id: string) => {
      const next = new Set(reminders);
      if (next.has(id)) {
          next.delete(id);
          alert('یادآوری برای این چالش لغو شد.');
      } else {
          next.add(id);
          alert('یادآوری تنظیم شد! ۲۴ ساعت قبل از پایان مهلت به شما اطلاع داده خواهد شد.');
      }
      setReminders(next);
  };

  // Category mapping: UI Label -> Data Category
  const categoryMap: {[key: string]: string} = {
      'همه': 'All',
      'فناوری': 'Technology',
      'هنر & دیزاین': 'Art',
      'کسب‌وکار': 'Business',
      'علوم پایه': 'Science',
      'اجتماعی': 'Social'
  };

  const filteredChallenges = MOCK_CHALLENGES.filter(challenge => {
      const matchesCategory = filter === 'All' || challenge.category === filter;
      const matchesSearch = challenge.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            challenge.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header & Filter */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
           <h2 className="text-3xl font-bold text-gray-900">چالش‌ها</h2>
           <p className="text-gray-500 text-sm mt-1">مسائل واقعی را حل کنید و جایزه بگیرید</p>
        </div>
        
        {config?.challengeConfig?.showFilters !== false && (
            <div className="flex gap-2">
            <div className="relative">
                <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                <input 
                    type="text" 
                    placeholder="جستجو در چالش‌ها..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10 pl-4 py-2 border rounded-lg focus:ring-primary focus:border-primary outline-none"
                />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50 text-gray-700">
                <Filter size={18} /> فیلتر
            </button>
            </div>
        )}
      </div>

      {/* Tags */}
      {config?.challengeConfig?.showFilters !== false && (
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
            {Object.keys(categoryMap).map((catLabel) => {
                const catValue = categoryMap[catLabel];
                const isActive = filter === catValue;
                return (
                    <button 
                        key={catLabel} 
                        onClick={() => setFilter(catValue)}
                        className={`px-4 py-1.5 rounded-full border text-sm transition-colors whitespace-nowrap
                            ${isActive ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-bold' : 'bg-white border-gray-200 text-gray-600 hover:border-primary hover:text-primary'}
                        `}
                    >
                        {catLabel}
                    </button>
                )
            })}
        </div>
      )}

      {/* Grid */}
      {filteredChallenges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredChallenges.map((challenge) => {
              const isParticipating = participatingIds.includes(challenge.id);
              const hasReminder = reminders.has(challenge.id);

              return (
              <div key={challenge.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow flex flex-col animate-fade-in">
                <div className="relative h-48">
                  <img src={challenge.image} alt={challenge.title} className="w-full h-full object-cover" />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold text-gray-800">
                    {challenge.category}
                  </div>
                  <div className={`absolute top-4 left-4 px-2 py-1 rounded text-xs font-bold text-white
                    ${challenge.difficulty === 'Easy' ? 'bg-green-500' : challenge.difficulty === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'}`}>
                    {challenge.difficulty === 'Hard' ? 'دشوار' : challenge.difficulty === 'Medium' ? 'متوسط' : 'ساده'}
                  </div>
                </div>
                
                <div className="p-5 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                     <h3 className="text-lg font-bold text-gray-900 line-clamp-2">{challenge.title}</h3>
                  </div>
                  <p className="text-gray-500 text-sm mb-4 line-clamp-3 flex-1">{challenge.description}</p>
                  
                  {config?.challengeConfig?.showPrize !== false && (
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-4 bg-gray-50 p-3 rounded-lg">
                        <div className="flex items-center gap-1 font-bold text-emerald-600">
                            <Coins size={16} />
                            {challenge.prize}
                        </div>
                        <div className="flex items-center gap-1">
                            <Clock size={16} />
                            {challenge.deadline}
                        </div>
                    </div>
                  )}

                  <div className="flex gap-2 mt-auto">
                     {isParticipating ? (
                        <div className="flex-1 flex gap-2">
                             <button 
                                onClick={() => toggleParticipation(challenge.id)}
                                className="flex-1 bg-green-50 text-green-700 border border-green-200 py-2 rounded-lg font-medium hover:bg-green-100 transition-colors flex items-center justify-center gap-1"
                             >
                                <CheckCircle size={16} />
                                شرکت کردید
                             </button>
                             <button 
                                onClick={() => toggleReminder(challenge.id)}
                                className={`px-3 border rounded-lg transition-colors flex items-center justify-center ${hasReminder ? 'bg-amber-100 text-amber-600 border-amber-200' : 'bg-white text-gray-400 border-gray-200 hover:text-amber-500'}`}
                                title={hasReminder ? "لغو یادآوری" : "تنظیم یادآوری پایان مهلت"}
                             >
                                {hasReminder ? <BellRing size={20} /> : <Bell size={20} />}
                             </button>
                        </div>
                     ) : (
                        <button 
                            onClick={() => toggleParticipation(challenge.id)}
                            className="flex-1 bg-primary text-white py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
                        >
                            شرکت در چالش
                        </button>
                     )}

                     <button 
                        onClick={() => handleMatchCheck(challenge.id, challenge.description)}
                        className="px-3 border border-gray-200 rounded-lg hover:bg-gray-50 text-gray-600" 
                        title="بررسی تطابق مهارت"
                     >
                        {matchingScores[challenge.id] === undefined ? (
                             <CheckCircle size={20} />
                        ) : matchingScores[challenge.id] === -1 ? (
                            <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                            <span className={`font-bold ${matchingScores[challenge.id] > 70 ? 'text-green-600' : 'text-orange-500'}`}>
                                {matchingScores[challenge.id]}%
                            </span>
                        )}
                     </button>
                  </div>
                </div>
              </div>
            )})}
          </div>
      ) : (
          <div className="text-center py-20 bg-white rounded-xl border border-dashed border-gray-300">
              <p className="text-gray-500 text-lg">هیچ چالشی با این مشخصات یافت نشد.</p>
              <button onClick={() => {setFilter('All'); setSearchQuery('');}} className="mt-4 text-primary hover:underline">مشاهده همه چالش‌ها</button>
          </div>
      )}
    </div>
  );
};
