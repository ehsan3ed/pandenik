import React, { useState } from 'react';
import { ViewState, User, Language, SiteConfig } from '../types';
import { Menu, Settings, Hexagon, Gem, Globe, LogIn, UserPlus, MessageCircle, AlertTriangle, X, Home, Lightbulb, FileText, Wrench, BookOpen, Target, Users, Newspaper } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  user: User | null; 
  language: Language;
  setLanguage: (lang: Language) => void;
  onLoginClick: () => void;
  siteConfig: SiteConfig;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, currentView, setCurrentView, user, language, setLanguage, onLoginClick, siteConfig
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isRTL = language !== 'en';
  const isMaintenance = siteConfig.plugins?.find(p => p.id === 'maintenance_mode')?.isActive;

  const handleNavClick = (view: ViewState) => {
      setCurrentView(view);
      setIsMobileMenuOpen(false); // Close mobile menu on click
  };

  const menuItems = [
      { view: ViewState.HOME, label: 'خانه', icon: Home },
      { view: ViewState.IDEA_LAB, label: 'ایده‌ها (پندار)', icon: Lightbulb },
      { view: ViewState.GOFTAR, label: 'طرح‌ها (گفتار)', icon: FileText },
      { view: ViewState.KERDAR, label: 'پروژه‌ها (کردار)', icon: Wrench },
      { view: ViewState.EXPERIENCE, label: 'تجربیات', icon: BookOpen },
      { view: ViewState.CHALLENGES, label: 'چالش‌ها', icon: Target },
      { view: ViewState.CO_CREATION, label: 'هم‌آفرینی', icon: Users },
      { view: ViewState.ARTICLES, label: 'مجله', icon: Newspaper },
  ];

  return (
    <div 
      className={`min-h-screen flex flex-col font-vazir ${isRTL ? 'text-right' : 'text-left'}`} 
      dir={isRTL ? 'rtl' : 'ltr'}
      style={{ backgroundColor: siteConfig.contentBgColor, fontSize: `${siteConfig.baseFontSize}px` }}
    >
      {isMaintenance && <div className="bg-yellow-500 text-black text-center py-2 text-sm font-bold">سایت در دست تعمیر است.</div>}

      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            <div className="flex-shrink-0 flex items-center cursor-pointer gap-2 group" onClick={() => handleNavClick(ViewState.HOME)}>
              <Hexagon className="h-8 w-8 group-hover:rotate-180 transition-transform" style={{ color: siteConfig.primaryColor }} />
              <span className="text-2xl font-bold text-gray-900 tracking-tighter">{siteConfig.logoText}</span>
            </div>

            {/* Desktop Nav */}
            <nav className={`hidden xl:flex ${isRTL ? 'space-x-4 space-x-reverse' : 'space-x-4'}`}>
              {menuItems.map(item => (
                  <button 
                    key={item.label}
                    onClick={() => handleNavClick(item.view)} 
                    className={`${currentView === item.view ? 'text-primary border-b-2 border-primary bg-indigo-50/50' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'} px-3 py-2 rounded-t-sm font-medium transition-all text-sm flex items-center gap-1.5`}
                  >
                      <item.icon size={16} className={currentView === item.view ? 'text-primary' : 'text-gray-400'} />
                      {item.label}
                  </button>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              {user ? (
                <>
                  {user.isAdmin && <button onClick={() => handleNavClick(ViewState.ADMIN_PANEL)} className="text-gray-600 hidden sm:block"><Settings size={20} /></button>}
                  <button onClick={() => handleNavClick(ViewState.PROFILE)} className="flex items-center gap-1 bg-amber-50 text-amber-700 px-3 py-1.5 rounded-full text-sm font-medium border border-amber-100"><Gem size={14} /><span>{user.niki}</span></button>
                  <button onClick={() => handleNavClick(ViewState.PROFILE)} className="flex items-center gap-2 bg-gray-100 px-3 py-1.5 rounded-full"><img src={user.avatar} className="h-8 w-8 rounded-full border-2 border-primary" /><span className="hidden sm:block text-sm font-medium">{user.name}</span></button>
                </>
              ) : (
                <button onClick={onLoginClick} className="flex items-center gap-1 bg-primary text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-indigo-700"><LogIn size={16} /> <span className="hidden sm:inline">ورود / ثبت نام</span></button>
              )}
              
              {/* Mobile Menu Button */}
              <button className="xl:hidden text-gray-500 p-2" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {isMobileMenuOpen && (
            <div className="xl:hidden bg-white border-t border-gray-100 absolute w-full left-0 top-16 shadow-lg animate-fade-in z-50">
                <nav className="flex flex-col p-4 space-y-2">
                    {menuItems.map(item => (
                        <button 
                            key={item.label}
                            onClick={() => handleNavClick(item.view)}
                            className={`text-right px-4 py-3 rounded-lg flex items-center gap-3 ${currentView === item.view ? 'bg-indigo-50 text-primary font-bold' : 'text-gray-600 hover:bg-gray-50'}`}
                        >
                            <item.icon size={18} />
                            {item.label}
                        </button>
                    ))}
                    {user && user.isAdmin && (
                        <button onClick={() => handleNavClick(ViewState.ADMIN_PANEL)} className="text-right px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-50 flex items-center gap-3">
                            <Settings size={18}/> پنل مدیریت
                        </button>
                    )}
                </nav>
            </div>
        )}
      </header>

      <main className="flex-grow">{children}</main>

      <footer className="bg-gray-900 text-white pt-12 pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div><h3 className="text-xl font-bold mb-4 flex items-center gap-2"><Hexagon className="h-6 w-6 text-primary" /> {siteConfig.logoText}</h3><p className="text-gray-400 text-sm leading-relaxed">{siteConfig.footerText}</p></div>
          <div><h4 className="font-bold mb-4 text-gray-200">لینک‌ها</h4><ul className="space-y-2 text-sm text-gray-400"><li><button onClick={()=>handleNavClick(ViewState.GOFTAR)}>بانک طرح‌ها</button></li><li><button onClick={()=>handleNavClick(ViewState.KERDAR)}>پروژه‌ها</button></li></ul></div>
          <div><h4 className="font-bold mb-4 text-gray-200">خدمات</h4><ul className="space-y-2 text-sm text-gray-400"><li><button onClick={()=>handleNavClick(ViewState.SECURE_PAYMENT)}>پرداخت امن</button></li></ul></div>
          <div><h4 className="font-bold mb-4 text-gray-200">خبرنامه</h4><div className="flex gap-2"><input type="email" placeholder="ایمیل" className="bg-gray-800 text-white px-4 py-2 rounded w-full text-sm" /><button className="bg-primary px-4 py-2 rounded text-sm">OK</button></div></div>
        </div>
        <div className="text-center text-gray-600 text-sm border-t border-gray-800 pt-8">© ۱۴۰۳ {siteConfig.logoText}. تمامی حقوق محفوظ است.</div>
      </footer>
    </div>
  );
};