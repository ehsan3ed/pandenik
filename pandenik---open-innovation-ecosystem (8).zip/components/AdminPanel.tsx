import React, { useState, useEffect } from 'react';
import { Settings, Users, Palette, FileText, BarChart, ShieldAlert, Save, Shield, Check, Plus, Trash2, Target, Flag, Smartphone, Mail, Lock, Layout, Plug, Edit, X, Lightbulb, Rocket, Briefcase, Filter } from 'lucide-react';
import { Role, SiteConfig, Plugin, Challenge, IdeaPost } from '../types';

interface AdminPanelProps {
  onUpdateConfig: (config: SiteConfig) => void;
  currentConfig: SiteConfig;
  allChallenges: Challenge[];
  setAllChallenges: (c: Challenge[]) => void;
  allIdeas: IdeaPost[];
  setAllIdeas: (i: IdeaPost[]) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ 
    onUpdateConfig, currentConfig, allChallenges, setAllChallenges, allIdeas, setAllIdeas 
}) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [contentFilter, setContentFilter] = useState<'All' | 'پندار' | 'گفتار' | 'کردار' | 'اجرا' | 'هم‌آفرینی'>('All');
  
  // Local state for configuration forms
  const [primaryColor, setPrimaryColor] = useState(currentConfig.primaryColor);
  const [logoText, setLogoText] = useState(currentConfig.logoText);
  const [contentBgColor, setContentBgColor] = useState(currentConfig.contentBgColor);
  const [baseFontSize, setBaseFontSize] = useState(currentConfig.baseFontSize);
  const [borderRadius, setBorderRadius] = useState(currentConfig.borderRadius || 'md');
  const [uiStyle, setUiStyle] = useState(currentConfig.uiStyle || 'flat');

  // Content Config
  const [homeTitle, setHomeTitle] = useState(currentConfig.homeTitle || '');
  const [homeSubtitle, setHomeSubtitle] = useState(currentConfig.homeSubtitle || '');
  const [footerText, setFooterText] = useState(currentConfig.footerText || '');

  // Services Config
  const [smsApiKey, setSmsApiKey] = useState(currentConfig.servicesConfig?.smsApiKey || '');
  const [emailHost, setEmailHost] = useState(currentConfig.servicesConfig?.emailHost || '');

  // Security Config
  const [enable2FA, setEnable2FA] = useState(currentConfig.securityConfig?.enable2FA || false);

  // Page Config
  const [selectedPage, setSelectedPage] = useState('home');

  // Edit Modal State
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [editType, setEditType] = useState<'challenge' | 'idea' | null>(null);

  // Counts for Dashboard
  const ideaCount = allIdeas.filter(i => i.step === 'پندار').length;
  const planCount = allIdeas.filter(i => i.step === 'گفتار').length;
  const projectCount = allIdeas.filter(i => i.step === 'کردار' || i.step === 'اجرا').length;
  const challengeCount = allChallenges.length;

  const handleDashboardClick = (tab: string, filter?: typeof contentFilter) => {
      setActiveTab(tab);
      if (filter) setContentFilter(filter);
  };

  const openEditModal = (item: any, type: 'challenge' | 'idea') => {
      setEditingItem({...item});
      setEditType(type);
  };

  const saveEdit = () => {
      if (!editingItem || !editType) return;
      if (editType === 'challenge') {
          const updated = allChallenges.map(c => c.id === editingItem.id ? editingItem : c);
          setAllChallenges(updated);
      } else {
          const updated = allIdeas.map(i => i.id === editingItem.id ? editingItem : i);
          setAllIdeas(updated);
      }
      setEditingItem(null);
      setEditType(null);
      alert('تغییرات با موفقیت ذخیره شد.');
  };

  const deleteIdea = (id: string) => {
      if(confirm('آیا از حذف این مورد اطمینان دارید؟')) {
          setAllIdeas(allIdeas.filter(i => i.id !== id));
      }
  }

  const deleteChallenge = (id: string) => {
      setAllChallenges(allChallenges.filter(c => c.id !== id));
  }

  const approveChallenge = (id: string) => {
      setAllChallenges(allChallenges.map(c => c.id === id ? {...c, status: 'Approved'} : c));
  }

  const handleSaveAppearance = () => {
    onUpdateConfig({ 
      ...currentConfig,
      primaryColor, logoText, contentBgColor, baseFontSize,
      borderRadius: borderRadius as any,
      uiStyle: uiStyle as any,
      homeTitle, homeSubtitle, footerText
    });
    alert('تنظیمات ظاهری ذخیره شد.');
  };

  const togglePlugin = (pluginId: string) => {
      const updatedPlugins = currentConfig.plugins.map(p => p.id === pluginId ? { ...p, isActive: !p.isActive } : p);
      onUpdateConfig({ ...currentConfig, plugins: updatedPlugins });
  };
  const handleSaveServices = () => { onUpdateConfig({...currentConfig, servicesConfig: {...currentConfig.servicesConfig, smsApiKey, emailHost}}); alert('Saved'); };
  const handleSaveSecurity = () => { onUpdateConfig({...currentConfig, securityConfig: {...currentConfig.securityConfig, enable2FA}}); alert('Saved'); };

  const renderContent = () => {
    switch(activeTab) {
      case 'dashboard':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in">
            {/* Ideas Card */}
            <div 
                className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-amber-400 cursor-pointer hover:shadow-md transition-all group"
                onClick={() => handleDashboardClick('content', 'پندار')}
            >
              <h3 className="text-gray-500 text-sm font-medium flex items-center gap-2">
                  <Lightbulb size={18} className="text-amber-500 group-hover:scale-110 transition-transform"/> 
                  ایده‌های ثبت شده (پندار)
              </h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">{ideaCount}</p>
              <span className="text-xs text-blue-600 mt-2 block group-hover:underline">مدیریت ایده‌ها ←</span>
            </div>

            {/* Plans Card */}
            <div 
                className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-indigo-500 cursor-pointer hover:shadow-md transition-all group"
                onClick={() => handleDashboardClick('content', 'گفتار')}
            >
              <h3 className="text-gray-500 text-sm font-medium flex items-center gap-2">
                  <FileText size={18} className="text-indigo-500 group-hover:scale-110 transition-transform"/> 
                  طرح‌های ثبت شده (گفتار)
              </h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">{planCount}</p>
              <span className="text-xs text-blue-600 mt-2 block group-hover:underline">مدیریت طرح‌ها ←</span>
            </div>

            {/* Projects Card */}
            <div 
                className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-green-500 cursor-pointer hover:shadow-md transition-all group"
                onClick={() => handleDashboardClick('content', 'کردار')}
            >
              <h3 className="text-gray-500 text-sm font-medium flex items-center gap-2">
                  <Rocket size={18} className="text-green-500 group-hover:scale-110 transition-transform"/> 
                  پروژه‌های اجرایی (کردار)
              </h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">{projectCount}</p>
              <span className="text-xs text-blue-600 mt-2 block group-hover:underline">مدیریت پروژه‌ها ←</span>
            </div>

            {/* Challenges Card */}
            <div 
                className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-red-500 cursor-pointer hover:shadow-md transition-all group"
                onClick={() => handleDashboardClick('challenges')}
            >
              <h3 className="text-gray-500 text-sm font-medium flex items-center gap-2">
                  <Target size={18} className="text-red-500 group-hover:scale-110 transition-transform"/> 
                  چالش‌های فعال
              </h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">{challengeCount}</p>
              <span className="text-xs text-blue-600 mt-2 block group-hover:underline">مدیریت چالش‌ها ←</span>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 lg:col-span-2">
              <h3 className="text-gray-500 text-sm font-medium">کاربران کل</h3>
              <div className="flex items-end justify-between">
                  <p className="text-3xl font-bold text-gray-800 mt-2">1,245</p>
                  <span className="text-green-500 text-sm font-bold bg-green-50 px-2 py-1 rounded">+12% رشد</span>
              </div>
            </div>
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 lg:col-span-2">
              <h3 className="text-gray-500 text-sm font-medium">افزونه‌های فعال</h3>
              <div className="flex items-center gap-2 mt-2">
                  {currentConfig.plugins.filter(p => p.isActive).map(p => (
                      <span key={p.id} className="bg-blue-50 text-blue-600 px-2 py-1 rounded text-xs border border-blue-100">{p.name}</span>
                  ))}
              </div>
            </div>
          </div>
        );

      case 'content':
          const filteredItems = allIdeas.filter(item => contentFilter === 'All' || item.step === contentFilter || (contentFilter === 'اجرا' && item.step === 'اجرا'));
          
          return (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 animate-fade-in">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                      <h3 className="text-xl font-bold flex items-center gap-2">
                          <FileText size={20} /> مدیریت محتوا ({filteredItems.length})
                      </h3>
                      
                      {/* Filter Tabs */}
                      <div className="flex bg-gray-100 p-1 rounded-lg overflow-x-auto w-full md:w-auto">
                          {['All', 'پندار', 'گفتار', 'کردار', 'اجرا'].map((filter) => (
                              <button
                                key={filter}
                                onClick={() => setContentFilter(filter as any)}
                                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all whitespace-nowrap ${contentFilter === filter ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                              >
                                  {filter === 'All' ? 'همه' : filter}
                              </button>
                          ))}
                      </div>
                  </div>

                  <div className="overflow-x-auto">
                      <table className="w-full text-right">
                          <thead className="bg-gray-50 text-gray-500 text-xs uppercase">
                              <tr>
                                  <th className="px-4 py-3">عنوان</th>
                                  <th className="px-4 py-3">نویسنده</th>
                                  <th className="px-4 py-3">مرحله</th>
                                  <th className="px-4 py-3">دسته‌بندی</th>
                                  <th className="px-4 py-3">تاریخ</th>
                                  <th className="px-4 py-3">وضعیت</th>
                                  <th className="px-4 py-3">عملیات</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                              {filteredItems.slice(0, 50).map(idea => ( // Show first 50 for perf
                                  <tr key={idea.id} className="hover:bg-gray-50 transition-colors">
                                      <td className="px-4 py-3 font-medium text-gray-900 max-w-[200px] truncate" title={idea.title}>{idea.title}</td>
                                      <td className="px-4 py-3 text-sm text-gray-600">{idea.author}</td>
                                      <td className="px-4 py-3">
                                          <span className={`px-2 py-1 rounded text-xs font-bold text-white
                                              ${idea.step === 'پندار' ? 'bg-amber-400' : idea.step === 'گفتار' ? 'bg-indigo-500' : idea.step === 'کردار' ? 'bg-green-500' : 'bg-purple-500'}`}>
                                              {idea.step}
                                          </span>
                                      </td>
                                      <td className="px-4 py-3 text-sm text-gray-600">{idea.category}</td>
                                      <td className="px-4 py-3 text-xs text-gray-400">{idea.date}</td>
                                      <td className="px-4 py-3">
                                          <span className={`px-2 py-0.5 rounded text-[10px] border ${idea.status === 'Approved' ? 'bg-green-50 text-green-600 border-green-200' : 'bg-yellow-50 text-yellow-600 border-yellow-200'}`}>
                                              {idea.status || 'بررسی نشده'}
                                          </span>
                                      </td>
                                      <td className="px-4 py-3 flex gap-2">
                                          <button onClick={() => openEditModal(idea, 'idea')} className="text-blue-600 hover:bg-blue-100 p-1.5 rounded"><Edit size={16}/></button>
                                          <button onClick={() => deleteIdea(idea.id)} className="text-red-600 hover:bg-red-100 p-1.5 rounded"><Trash2 size={16}/></button>
                                      </td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                      {filteredItems.length === 0 && <div className="text-center py-8 text-gray-500">هیچ موردی یافت نشد.</div>}
                  </div>
              </div>
          );
      
      case 'challenges':
          return (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Target size={20} /> مدیریت چالش‌ها</h3>
                  <div className="space-y-4">
                      {allChallenges.map(c => (
                          <div key={c.id} className="flex items-center justify-between p-4 border rounded-lg bg-gray-50">
                              <div>
                                  <h4 className="font-bold text-gray-900">{c.title}</h4>
                                  <span className="text-xs text-gray-500">{c.company}</span>
                              </div>
                              <div className="flex items-center gap-3">
                                  <span className={`text-xs px-2 py-1 rounded font-bold ${c.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                      {c.status === 'Approved' ? 'تایید شده' : 'در انتظار'}
                                  </span>
                                  {c.status !== 'Approved' && (
                                      <button onClick={() => approveChallenge(c.id)} className="text-green-600 hover:bg-green-100 p-1 rounded">
                                          <Check size={18} />
                                      </button>
                                  )}
                                  <button onClick={() => openEditModal(c, 'challenge')} className="text-blue-600 hover:bg-blue-100 p-1 rounded"><Edit size={18}/></button>
                                  <button onClick={() => deleteChallenge(c.id)} className="text-red-600 hover:bg-red-100 p-1 rounded">
                                      <Trash2 size={18} />
                                  </button>
                              </div>
                          </div>
                      ))}
                      {allChallenges.length === 0 && <p className="text-center text-gray-500">هیچ چالشی وجود ندارد.</p>}
                  </div>
              </div>
          );

      case 'appearance':
        return (
          <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Palette size={20} /> شخصی‌سازی ظاهر سایت</h3>
            
            <div className="space-y-8">
              {/* Colors & Fonts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">رنگ اصلی برند</label>
                    <div className="flex items-center gap-4">
                      <input 
                        type="color" 
                        value={primaryColor}
                        onChange={(e) => setPrimaryColor(e.target.value)}
                        className="h-10 w-20 rounded border cursor-pointer"
                      />
                      <span className="text-gray-500 font-mono">{primaryColor}</span>
                    </div>
                  </div>
                   <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">رنگ پس‌زمینه محتوا</label>
                    <div className="flex items-center gap-4">
                      <input 
                        type="color" 
                        value={contentBgColor}
                        onChange={(e) => setContentBgColor(e.target.value)}
                        className="h-10 w-20 rounded border cursor-pointer"
                      />
                      <span className="text-gray-500 font-mono">{contentBgColor}</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">اندازه فونت پایه ({baseFontSize}px)</label>
                    <input 
                      type="range" 
                      min="12" 
                      max="24" 
                      step="1"
                      value={baseFontSize}
                      onChange={(e) => setBaseFontSize(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                   <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">متن لوگو</label>
                    <input 
                      type="text" 
                      value={logoText}
                      onChange={(e) => setLogoText(e.target.value)}
                      className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary"
                    />
                  </div>
              </div>

              {/* Content Editing */}
              <div>
                  <h4 className="font-bold text-gray-800 mb-4">متون صفحه اصلی و فوتر</h4>
                  <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">تیتر اصلی (Hero)</label>
                        <input type="text" value={homeTitle} onChange={e => setHomeTitle(e.target.value)} className="w-full border rounded px-3 py-2" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">زیرعنوان</label>
                        <textarea value={homeSubtitle} onChange={e => setHomeSubtitle(e.target.value)} className="w-full border rounded px-3 py-2" rows={2} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">متن فوتر</label>
                        <textarea value={footerText} onChange={e => setFooterText(e.target.value)} className="w-full border rounded px-3 py-2" rows={2} />
                      </div>
                  </div>
              </div>

              <button 
                onClick={handleSaveAppearance}
                className="flex items-center gap-2 bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
              >
                <Save size={18} /> ذخیره تغییرات
              </button>
            </div>
          </div>
        );
      
      case 'services':
          return (
              <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Smartphone size={20} /> تنظیمات سرویس‌ها</h3>
                  <div className="space-y-6">
                      <div className="p-4 bg-gray-50 rounded-lg border">
                          <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2"><Smartphone size={16}/> پنل پیامک (SMS)</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                  <label className="block text-xs font-bold text-gray-500 mb-1">API Key</label>
                                  <input type="password" value={smsApiKey} onChange={e => setSmsApiKey(e.target.value)} className="w-full border rounded px-3 py-2" />
                              </div>
                              <div>
                                  <label className="block text-xs font-bold text-gray-500 mb-1">ارائه‌دهنده</label>
                                  <select className="w-full border rounded px-3 py-2">
                                      <option>KavehNegar</option>
                                      <option>Magfa</option>
                                      <option>SMS.ir</option>
                                  </select>
                              </div>
                          </div>
                      </div>

                       <div className="p-4 bg-gray-50 rounded-lg border">
                          <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2"><Mail size={16}/> تنظیمات ایمیل (SMTP)</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                  <label className="block text-xs font-bold text-gray-500 mb-1">SMTP Host</label>
                                  <input type="text" value={emailHost} onChange={e => setEmailHost(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="smtp.gmail.com" />
                              </div>
                          </div>
                      </div>
                      <button onClick={handleSaveServices} className="bg-blue-600 text-white px-4 py-2 rounded">ذخیره تنظیمات</button>
                  </div>
              </div>
          );
      case 'security':
          return (
               <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Lock size={20} /> امنیت و دسترسی</h3>
                   <div className="space-y-4">
                       <label className="flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                           <input type="checkbox" checked={enable2FA} onChange={e => setEnable2FA(e.target.checked)} className="w-5 h-5 text-indigo-600" />
                           <div>
                               <div className="font-bold text-gray-800">احراز هویت دو مرحله‌ای (2FA)</div>
                               <div className="text-xs text-gray-500">اجبار کاربران به تایید شماره موبایل هنگام ورود</div>
                           </div>
                       </label>
                       <button onClick={handleSaveSecurity} className="bg-blue-600 text-white px-4 py-2 rounded">ذخیره تنظیمات</button>
                   </div>
               </div>
          );
      case 'pages':
          return (
              <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                   <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Layout size={20} /> مدیریت صفحات سایت</h3>
                   <div className="mb-6">
                       <label className="block text-sm font-medium text-gray-700 mb-2">انتخاب صفحه برای ویرایش</label>
                       <select value={selectedPage} onChange={e => setSelectedPage(e.target.value)} className="w-full border rounded px-4 py-2">
                           <option value="home">صفحه اصلی (Home)</option>
                           <option value="challenges">چالش‌ها</option>
                           <option value="ideaLab">ایده پردازی</option>
                           <option value="profile">پروفایل کاربری</option>
                       </select>
                   </div>
                   
                   <div className="p-4 bg-yellow-50 border border-yellow-200 rounded text-yellow-800 text-sm">
                       تنظیمات پیشرفته {selectedPage} در این بخش قرار می‌گیرد. (برای جلوگیری از پیچیدگی فعلاً غیرفعال است)
                   </div>
              </div>
          );
      
      default:
        return (
            <div className="text-center py-20">
                <p className="text-gray-500 mb-2">این بخش در حال توسعه است</p>
                <button onClick={() => setActiveTab('dashboard')} className="text-indigo-600 hover:underline">بازگشت به داشبورد</button>
            </div>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row gap-8 relative">
       {/* Sidebar Navigation */}
       <div className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-gray-100 p-4 h-fit sticky top-24">
           <h2 className="text-lg font-bold text-gray-900 mb-6 px-4 border-b pb-4">پنل مدیریت</h2>
           <nav className="space-y-1">
               {[
                   {id: 'dashboard', icon: BarChart, label: 'داشبورد'},
                   {id: 'content', icon: FileText, label: 'مدیریت محتوا'},
                   {id: 'challenges', icon: Target, label: 'مدیریت چالش‌ها'},
                   {id: 'users', icon: Users, label: 'کاربران'},
                   {id: 'appearance', icon: Palette, label: 'ظاهر و قالب'},
                   {id: 'services', icon: Smartphone, label: 'سرویس‌ها'},
                   {id: 'plugins', icon: Plug, label: 'افزونه‌ها'},
                   {id: 'security', icon: Lock, label: 'امنیت'},
                   {id: 'pages', icon: Layout, label: 'مدیریت صفحات'},
               ].map(item => (
                   <button 
                    key={item.id} 
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-colors ${activeTab === item.id ? 'bg-[#f0f9ff] text-indigo-700 font-bold border-r-4 border-indigo-600' : 'text-gray-600 hover:bg-gray-50'}`}
                   >
                       <item.icon size={18} /> {item.label}
                   </button>
               ))}
           </nav>
       </div>

       {/* Main Content Area */}
       <div className="flex-1 min-h-[500px]">
           {renderContent()}
       </div>

       {/* Edit Modal */}
       {editingItem && (
        <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-2xl p-6 shadow-2xl animate-fade-in max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6 border-b pb-4">
                    <h3 className="text-xl font-bold">ویرایش {editType === 'challenge' ? 'چالش' : 'محتوا'}</h3>
                    <button onClick={() => setEditingItem(null)} className="text-gray-400 hover:text-red-500"><X size={24}/></button>
                </div>
                <div className="space-y-4">
                    <div><label className="block text-sm font-bold">عنوان</label><input className="w-full border p-2 rounded" value={editingItem.title} onChange={e => setEditingItem({...editingItem, title: e.target.value})}/></div>
                    <div>
                        <label className="block text-sm font-bold">توضیحات</label>
                        <textarea 
                            className="w-full border p-2 rounded" 
                            rows={5} 
                            value={editType === 'challenge' ? editingItem.description : editingItem.content} 
                            onChange={e => setEditingItem({...editingItem, [editType === 'challenge' ? 'description' : 'content']: e.target.value})}
                        />
                    </div>
                </div>
                <div className="flex justify-end gap-3 mt-6">
                    <button onClick={() => setEditingItem(null)} className="px-4 py-2 border rounded">انصراف</button>
                    <button onClick={saveEdit} className="px-4 py-2 bg-indigo-600 text-white rounded">ذخیره</button>
                </div>
            </div>
        </div>
       )}
    </div>
  );
};