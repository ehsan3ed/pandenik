
import React from 'react';
import { ViewState } from '../types';
import { ShieldCheck, Lock, Bitcoin, Scale, Mail, Phone, MapPin } from 'lucide-react';

interface StaticPageProps {
  view: ViewState;
}

export const StaticPage: React.FC<StaticPageProps> = ({ view }) => {
  if (view === ViewState.RULES) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-6 border-b pb-4">
            <Scale className="text-primary w-8 h-8" />
            <h1 className="text-3xl font-bold text-gray-900">قوانین و مالکیت معنوی</h1>
          </div>
          <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
            <h3 className="text-xl font-bold text-gray-900">۱. حق مالکیت ایده (IP)</h3>
            <p>تمام ایده‌های ثبت شده در مرحله "گفتار" و "کردار" مشمول قانون کپی‌رایت پندنیک هستند. تاریخ و ساعت دقیق ثبت به عنوان گواهی مالکیت شما در بلاکچین خصوصی سایت ذخیره می‌شود.</p>
            
            <h3 className="text-xl font-bold text-gray-900">۲. قرارداد عدم افشا (NDA)</h3>
            <p>تمامی سرمایه‌گذاران و شرکت‌هایی که قصد مشاهده جزئیات طرح‌های فروشی را دارند، ملزم به امضای دیجیتال قرارداد NDA هستند.</p>
            
            <h3 className="text-xl font-bold text-gray-900">۳. قوانین محتوا</h3>
            <p>انتشار هرگونه محتوای خلاف قوانین جمهوری اسلامی ایران، توهین‌آمیز یا کلاهبرداری ممنوع است و منجر به مسدود شدن حساب کاربری می‌شود.</p>
          </div>
        </div>
      </div>
    );
  }

  if (view === ViewState.SECURE_PAYMENT) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-6 border-b pb-4">
            <ShieldCheck className="text-green-600 w-8 h-8" />
            <h1 className="text-3xl font-bold text-gray-900">پرداخت امن و ارز دیجیتال</h1>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
             <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
                <h3 className="font-bold flex items-center gap-2 mb-4"><Bitcoin className="text-orange-500"/> پرداخت با کریپتو</h3>
                <p className="text-sm text-gray-600 mb-4">ما از شبکه‌های TRC20 و ERC20 پشتیبانی می‌کنیم. تمامی تراکنش‌ها به صورت خودکار تایید می‌شوند.</p>
                <div className="bg-white p-3 rounded border font-mono text-xs break-all text-gray-500">
                   0x71C7656EC7ab88b098defB751B7401B5f6d8976F
                </div>
                <p className="text-xs text-gray-400 mt-1 text-center">آدرس کیف پول جهت واریز وجه (نمونه)</p>
             </div>
             
             <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
                <h3 className="font-bold flex items-center gap-2 mb-4"><Lock className="text-blue-500"/> اسکرو (Escrow)</h3>
                <p className="text-sm text-gray-600">
                    مبلغ پرداختی برای پروژه‌ها نزد سایت به امانت می‌ماند و تنها پس از تایید خریدار و تحویل مستندات، به حساب فروشنده آزاد می‌شود.
                </p>
             </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === ViewState.CONTACT_US) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center">
             <h1 className="text-3xl font-bold text-gray-900 mb-8">ارتباط با پشتیبانی</h1>
             
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                 <div className="flex flex-col items-center">
                     <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3"><Phone /></div>
                     <h3 className="font-bold">تلفن</h3>
                     <p className="text-gray-500">۰۲۱-۸۸۸۸۸۸۸۸</p>
                 </div>
                 <div className="flex flex-col items-center">
                     <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-3"><Mail /></div>
                     <h3 className="font-bold">ایمیل</h3>
                     <p className="text-gray-500">support@pandenik.com</p>
                 </div>
                 <div className="flex flex-col items-center">
                     <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-600 mb-3"><MapPin /></div>
                     <h3 className="font-bold">دفتر مرکزی</h3>
                     <p className="text-gray-500">تهران، پارک علم و فناوری</p>
                 </div>
             </div>
        </div>
      </div>
    );
  }

  return null;
};
