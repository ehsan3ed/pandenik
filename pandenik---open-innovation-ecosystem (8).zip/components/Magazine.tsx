
import React, { useState } from 'react';
import { Article } from '../types';
import { ArrowRight, Calendar, User, ArrowLeft } from 'lucide-react';

interface MagazineProps {
  articles: Article[];
  onBack: () => void;
}

export const Magazine: React.FC<MagazineProps> = ({ articles, onBack }) => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  if (selectedArticle) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in">
        <button 
          onClick={() => setSelectedArticle(null)}
          className="flex items-center gap-2 text-gray-600 hover:text-indigo-600 mb-6 transition-colors"
        >
          <ArrowRight size={20} /> بازگشت به مجله
        </button>
        
        <article className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <img src={selectedArticle.image} alt={selectedArticle.title} className="w-full h-64 md:h-96 object-cover" />
          
          <div className="p-8 md:p-12">
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
              <span className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full font-bold">{selectedArticle.category}</span>
              <span className="flex items-center gap-1"><Calendar size={16}/> {selectedArticle.date}</span>
              <span className="flex items-center gap-1"><User size={16}/> {selectedArticle.author}</span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-8 leading-tight">{selectedArticle.title}</h1>
            
            <div className="prose prose-lg prose-indigo max-w-none text-gray-700 leading-loose whitespace-pre-line">
              {selectedArticle.content}
            </div>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">مجله پندنیک</h2>
          <p className="text-gray-500 mt-2">تازه‌ترین مقالات دنیای نوآوری و کسب‌وکار</p>
        </div>
        <button onClick={onBack} className="text-gray-500 hover:text-gray-900 flex items-center gap-2">
            بازگشت <ArrowLeft size={20}/>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {articles.map((article) => (
          <div 
            key={article.id} 
            onClick={() => setSelectedArticle(article)}
            className="group bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden cursor-pointer hover:shadow-md transition-all hover:-translate-y-1"
          >
            <div className="h-48 overflow-hidden relative">
              <img src={article.image} alt={article.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-gray-800 shadow-sm">
                {article.category}
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
                <Calendar size={14} /> {article.date}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors line-clamp-2">
                {article.title}
              </h3>
              <p className="text-gray-500 text-sm line-clamp-3 mb-4 leading-relaxed">
                {article.excerpt}
              </p>
              <span className="text-indigo-600 font-medium text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                مطالعه مقاله <ArrowLeft size={16} />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
