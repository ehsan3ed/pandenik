
import React from 'react';
import { ViewState, SiteConfig } from '../types';
import { ArrowLeft, Rocket, Users, Target, ShieldCheck, FileText, Layers } from 'lucide-react';

interface HeroProps {
  onCtaClick: (view: ViewState) => void;
  config?: SiteConfig;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick, config }) => {
  const title = config?.homeTitle ? (
    <>
      <span className="block">{config.homeTitle.split(' ').slice(0, 3).join(' ')}</span>
      <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500">{config.homeTitle.split(' ').slice(3).join(' ')}</span>
    </>
  ) : (
    <>
      <span className="block">تبدیل رویاهای خام به</span>
      <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500">واقعیت‌های پول‌ساز</span>
    </>
  );

  return (
    <div className="relative overflow-hidden bg-white">
        {/* Creative Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-indigo-800 to-purple-900 opacity-95"></div>
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        
        {/* Floating Shapes */}
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-72 h-72 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse delay-75"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="pb-8 sm:pb-16 md:pb-20 lg:max-w-3xl lg:w-full lg:pb-28 xl:pb-32 pt-24 px-4 sm:px-6 lg:px-8">
            <div className="text-right">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-white/20 text-indigo-100 text-sm font-medium mb-6 backdrop-blur-sm">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                  اکوسیستم نوآوری باز
              </div>
              <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl mb-6 leading-tight">
                {config?.homeTitle ? (
                    // Simple split for coloring if custom title
                    <>
                        <span className="block">{config.homeTitle.split(' ').slice(0, Math.ceil(config.homeTitle.split(' ').length / 2)).join(' ')}</span>
                        <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500">
                            {config.homeTitle.split(' ').slice(Math.ceil(config.homeTitle.split(' ').length / 2)).join(' ')}
                        </span>
                    </>
                ) : (
                    <>
                        <span className="block">تبدیل رویاهای خام به</span>
                        <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500">واقعیت‌های پول‌ساز</span>
                    </>
                )}
              </h1>
              <p className="mt-4 text-lg text-indigo-100 sm:max-w-xl md:text-xl lg:mx-0 leading-relaxed">
                {config?.homeSubtitle || "در پندنیک، ایده‌های شما خریدار دارند. چالش‌ها را حل کنید، طرح‌های خود را بفروشید و با کسب امتیاز \"نیکی\"، درآمد دلاری و ارزی داشته باشید."}
              </p>
              
              <div className="mt-8 sm:flex sm:justify-start gap-4">
                <div className="rounded-md shadow">
                  <button
                    onClick={() => onCtaClick(ViewState.CHALLENGES)}
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-bold rounded-xl text-indigo-700 bg-white hover:bg-gray-50 md:py-4 md:text-lg transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                  >
                    <Target className="ml-2" size={20} />
                    شروع چالش‌ها
                  </button>
                </div>
                <div className="mt-3 sm:mt-0">
                  <button
                    onClick={() => onCtaClick(ViewState.IDEA_LAB)}
                    className="w-full flex items-center justify-center px-8 py-3 border border-white/30 backdrop-blur-sm text-base font-bold rounded-xl text-white bg-white/10 hover:bg-white/20 md:py-4 md:text-lg transition-all"
                  >
                    <Rocket className="ml-2" size={20} />
                    ثبت ایده و طرح
                  </button>
                </div>
              </div>

              {/* Trust Badges */}
              {config?.homeConfig?.showTrust !== false && (
                <div className="mt-10 flex flex-wrap gap-6 text-indigo-200 text-sm">
                    <div className="flex items-center gap-2">
                        <ShieldCheck className="text-green-400" />
                        <span>پرداخت امن و تضمین‌شده</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <FileText className="text-yellow-400" />
                        <span>رعایت حقوق مالکیت معنوی</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Layers className="text-blue-400" />
                        <span>پشتیبانی از پندار تا اجرا</span>
                    </div>
                </div>
              )}
            </div>
        </div>
      </div>
      
      {/* Abstract Graphic Right Side (Desktop) */}
      <div className="hidden lg:block lg:absolute lg:inset-y-0 lg:left-0 lg:w-1/2">
        <div className="h-full w-full bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1740&q=80')] bg-cover bg-center" style={{clipPath: 'polygon(0 0, 100% 0, 85% 100%, 0% 100%)'}}>
            <div className="absolute inset-0 bg-indigo-900/40 mix-blend-multiply"></div>
        </div>
      </div>

      {/* Feature stats */}
      {config?.homeConfig?.showStats !== false && (
        <div className="bg-gray-50 py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div className="p-8 bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-indigo-50 mb-6">
                            <Target className="h-8 w-8 text-primary" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">چالش‌های واقعی</h3>
                        <p className="text-gray-500 leading-relaxed">
                            کارآفرینان مشکلات را مطرح می‌کنند و شما با حل آن‌ها جایزه نقدی و اعتباری دریافت می‌کنید.
                        </p>
                    </div>
                    <div className="p-8 bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-50 mb-6">
                            <Rocket className="h-8 w-8 text-green-600" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">چرخه حیات ایده</h3>
                        <p className="text-gray-500 leading-relaxed">
                            ایده (پندار) را به طرح (گفتار) و سپس پروژه (کردار) تبدیل کنید و برای هر مرحله سرمایه‌گذار جذب کنید.
                        </p>
                    </div>
                    <div className="p-8 bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-amber-50 mb-6">
                            <Users className="h-8 w-8 text-amber-600" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">اقتصاد مبتنی بر "نیکی"</h3>
                        <p className="text-gray-500 leading-relaxed">
                            با فعالیت مفید، امتیاز "نیکی" بگیرید و آن را به ارزهای دیجیتال یا خدمات واقعی تبدیل کنید.
                        </p>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
