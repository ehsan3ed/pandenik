import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const analyzeIdea = async (ideaText: string, category: string): Promise<string> => {
  if (!apiKey) return "API Key not configured. (شبیه‌سازی: ایده شما پتانسیل بالایی دارد اما نیاز به تحقیق بازار بیشتر دارد.)";

  try {
    const model = "gemini-2.5-flash";
    const prompt = `
      به عنوان یک مشاور نوآوری در پلتفرم "پندنیک"، این ایده را در دسته‌بندی "${category}" تحلیل کن:
      "${ideaText}"
      
      لطفاً یک بازخورد کوتاه (حداکثر ۳ خط) شامل نقاط قوت و یک پیشنهاد بهبود ارائه بده. لحن باید حرفه‌ای و تشویق‌کننده باشد. زبان: فارسی.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "خطا در دریافت پاسخ از هوش مصنوعی.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "متاسفانه در حال حاضر امکان ارتباط با هوش مصنوعی وجود ندارد.";
  }
};

export const matchSkillsToChallenge = async (userSkills: string[], challengeDesc: string): Promise<number> => {
  if (!apiKey) return Math.floor(Math.random() * 40) + 60; // Mock score

  try {
     const model = "gemini-2.5-flash";
     const prompt = `
      من مهارت‌های زیر را دارم: ${userSkills.join(', ')}.
      چالش این است: "${challengeDesc}".
      
      فقط یک عدد بین 0 تا 100 برگردان که نشان‌دهنده درصد تطابق مهارت‌های من با این چالش باشد. هیچ متن دیگری ننویس.
     `;
     
     const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
     });
     
     const score = parseInt(response.text.trim());
     return isNaN(score) ? 50 : score;
  } catch (error) {
    return 50;
  }
}
