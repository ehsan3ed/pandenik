
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/analytics';

// ⚠️ IMPORTANT: Replace these values with your OWN Firebase project configuration
// Get this from: https://console.firebase.google.com/ -> Project Settings -> General -> Your Apps
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "G-MEASUREMENT_ID"
};

// Initialize Firebase
// Check if apps are already initialized to avoid errors during hot-reload
const app = firebase.apps.length ? firebase.app() : firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const googleProvider = new firebase.auth.GoogleAuthProvider();

// Initialize Analytics (safely, as it might depend on environment)
let analytics = null;
try {
  // Only initialize analytics if config is real
  if (firebaseConfig.apiKey !== "YOUR_API_KEY_HERE" && firebaseConfig.apiKey !== "") {
    analytics = firebase.analytics();
  }
} catch (e) {
  console.warn("Firebase Analytics could not be initialized", e);
}

// Helper to check if config is valid (not placeholders)
const isFirebaseConfigured = () => {
    return firebaseConfig.apiKey !== "YOUR_API_KEY_HERE" && firebaseConfig.apiKey !== "";
};

// Wrappers to maintain compatibility with App.tsx which expects v9 modular functions
const signInWithPopup = (authInstance: any, provider: any) => authInstance.signInWithPopup(provider);
const signOut = (authInstance: any) => authInstance.signOut();
const onAuthStateChanged = (authInstance: any, callback: any) => authInstance.onAuthStateChanged(callback);

export { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  db, 
  isFirebaseConfigured, 
  analytics 
};
