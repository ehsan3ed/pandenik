import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Hero } from './components/Hero';
import { ChallengeHub } from './components/ChallengeHub';
import { IdeaLab } from './components/IdeaLab';
import { Profile } from './components/Profile';
import { AdminPanel } from './components/AdminPanel';
import { StaticPage } from './components/StaticPages';
import { Magazine } from './components/Magazine';
import { SEOHandler } from './components/SEOHandler';
import { PluginInjector } from './components/PluginInjector';
import { ViewState, User, Language, SiteConfig, Article, Challenge, IdeaPost } from './types';
import { X, AlertTriangle } from 'lucide-react';

// Import Firebase Services (Modular)
import { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  isFirebaseConfigured 
} from './services/firebase';

// Mock Data for Initial Setup or Fallback
const MOCK_USER_TEMPLATE: User = {
  id: 'temp_user',
  name: 'کاربر جدید',
  email: 'new@example.com',
  title: 'تازه وارد',
  avatar: 'https://picsum.photos/200/200?random=new',
  level: 'Egg',
  skills: [],
  bio: 'هنوز بیوگرافی نوشته نشده است.',
  niki: 0,
  isAdmin: false, 
  participatingChallengeIds: [],
};

const generateRealContent = (): IdeaPost[] => {
    const categories = ['فناوری', 'کشاورزی', 'پزشکی', 'هنر', 'آموزش', 'محیط زیست', 'فین‌تک', 'گردشگری'];
    const topics = ["زعفران ارگانیک", "مدیریت دیابت", "خوشنویسی مدرن", "آموزش ریاضیات", "بازیافت زباله شهری", "صرافی غیرمتمرکز", "توریسم", "انبارداری هوشمند", "تولید محتوای خودکار", "تصفیه آب"];
    const authors = ["علی رضایی", "سارا احمدی", "دکتر محمد کمالی", "مهندس زهرا نوری", "آرش مهدوی"];
    let items: IdeaPost[] = [];
    let counter = 1;

    for(let i=0; i<30; i++) {
        items.push({
            id: `idea_${counter++}`,
            title: `ایده نوآورانه در زمینه ${topics[i%topics.length]}`,
            author: authors[i%authors.length],
            authorAvatar: `https://i.pravatar.cc/150?u=${counter}`,
            content: `توضیحات کامل درباره ایده ${topics[i%topics.length]}...`,
            category: categories[i%categories.length],
            step: 'پندار',
            likes: Math.floor(Math.random()*200),
            comments: Math.floor(Math.random()*50),
            date: '2 روز پیش',
            isFree: true,
            status: i % 3 === 0 ? 'Approved' : 'Pending'
        });
    }
    return items;
};

const MOCK_CHALLENGES_DATA: Challenge[] = [
  {
    id: '1',
    title: 'طراحی بسته بندی پایدار برای مواد غذایی',
    description: 'ما به دنبال راهکاری برای حذف پلاستیک از بسته‌بندی محصولات لبنی خود هستیم. راهکار باید ارزان و تجزیه‌پذیر باشد.',
    company: 'کاله',
    prize: '۵۰,۰۰۰,۰۰۰ تومان',
    deadline: '۱۴۰۳/۰۸/۰۱',
    category: 'Science',
    difficulty: 'Hard',
    image: 'https://picsum.photos/400/300?random=1',
    status: 'Approved'
  },
  {
    id: '2',
    title: 'طراحی لوگو و هویت بصری استارتاپ فین‌تک',
    description: 'طراحی مینیمال برای یک صرافی غیرمتمرکز. نیاز به لوگو، پالت رنگی و فونت سازمانی.',
    company: 'کریپتو پی',
    prize: '۱۵,۰۰۰,۰۰۰ تومان',
    deadline: '۱۴۰۳/۰۷/۱۵',
    category: 'Art',
    difficulty: 'Medium',
    image: 'https://picsum.photos/400/300?random=2',
    status: 'Approved'
  },
  {
    id: '3',
    title: 'بهینه‌سازی الگوریتم مسیریابی پهپاد',
    description: 'کد پایتون برای یافتن کوتاه‌ترین مسیر در فضای سه بعدی با وجود موانع متحرک.',
    company: 'پست هوایی',
    prize: '۰.۵ بیت‌کوین',
    deadline: '۱۴۰۳/۰۹/۱۰',
    category: 'Technology',
    difficulty: 'Hard',
    image: 'https://picsum.photos/400/300?random=3',
    status: 'Pending'
  }
];

const MOCK_ARTICLES: Article[] = [
    {
        id: '1',
        title: 'نوآوری باز چیست و چرا آینده کسب‌وکارهاست؟',
        excerpt: 'در دنیای امروز، شرکت‌ها نمی‌توانند فقط به منابع داخلی خود تکیه کنند. نوآوری باز راهی برای استفاده از خرد جمعی است.',
        content: `نوآوری باز (Open Innovation) یک پارادایم است که فرض می‌کند شرکت‌ها می‌توانند و باید از ایده‌های خارجی و همچنین ایده‌های داخلی استفاده کنند.

        مزایای اصلی نوآوری باز:
        ۱. کاهش هزینه‌های تحقیق و توسعه (R&D)
        ۲. افزایش سرعت ورود به بازار
        ۳. دسترسی به بازارهای جدید
        ۴. استفاده از خلاقیت‌های پراکنده در سطح جامعه

        در پلتفرم پندنیک، ما تلاش می‌کنیم تا این ارتباط را بین نوآوران و شرکت‌ها برقرار کنیم.`,
        author: 'دکتر نوآوری',
        date: '۱۴۰۳/۰۶/۱۵',
        image: 'https://picsum.photos/800/400?random=a1',
        category: 'کسب‌وکار',
        status: 'Published'
    },
    {
        id: '2',
        title: 'چگونه ایده خود را به MVP تبدیل کنیم؟',
        excerpt: 'راهنمای گام به گام برای ساخت حداقل محصول قابل ارائه و تست بازار با کمترین هزینه.',
        content: `ساخت MVP (Minimum Viable Product) مهم‌ترین گام برای استارتاپ‌هاست.

        مراحل ساخت MVP:
        ۱. شناسایی مشکل اصلی
        ۲. تعیین ارزش پیشنهادی
        ۳. طراحی جریان کاربری ساده
        ۴. توسعه ویژگی‌های حیاتی
        ۵. دریافت بازخورد و تکرار

        فراموش نکنید که MVP باید قابل استفاده باشد، نه کامل.`,
        author: 'مهندس ساخت',
        date: '۱۴۰۳/۰۶/۱۰',
        image: 'https://picsum.photos/800/400?random=a2',
        category: 'فناوری',
        status: 'Published'
    }
];

const INITIAL_CONFIG: SiteConfig = {
    primaryColor: '#0052cc', // Pandenik Blue
    secondaryColor: '#ff9900', // Pandenik Orange/Gold
    logoText: 'پند نیک',
    contentBgColor: '#f8fafc',
    baseFontSize: 16,
    homeTitle: 'تبدیل رویاهای خام به واقعیت‌های پول‌ساز',
    homeSubtitle: 'در پندنیک، ایده‌های شما خریدار دارند. چالش‌ها را حل کنید، طرح‌های خود را بفروشید و با کسب امتیاز "نیکی"، درآمد دلاری و ارزی داشته باشید.',
    footerText: 'اکوسیستم نوآوری باز و بین‌رشته‌ای. جایی که ایده‌های خام به واقعیت‌های پول‌ساز تبدیل می‌شوند.',
    homeConfig: { showStats: true, showTrust: true },
    challengeConfig: { showFilters: true, showPrize: true },
    ideaLabConfig: { showSteps: true, allowGuestView: false },
    profileConfig: { showChart: true, showSocial: true },
    pageLayouts: {
        home: [
            { id: 'hero', title: 'بخش اصلی', visible: true, order: 1 },
            { id: 'stats', title: 'آمار', visible: true, order: 2 },
            { id: 'lifecycle', title: 'چرخه حیات', visible: true, order: 3 },
        ],
        profile: [
            { id: 'header', title: 'هدر پروفایل', visible: true, order: 1 },
            { id: 'dna', title: 'DNA حرفه‌ای', visible: true, order: 2 },
            { id: 'experience', title: 'سوابق', visible: true, order: 3 },
        ]
    },
    plugins: [
        { 
            id: 'seo_pack', 
            name: 'Pandenik SEO Pack', 
            description: 'مدیریت متاتگ‌ها و عناوین صفحات برای گوگل به صورت واقعی.', 
            version: '2.0.0', 
            author: 'Pandenik Team', 
            isActive: true, 
            icon: 'Search' 
        },
        { 
            id: 'support_chat', 
            name: 'Live Support Chat (Script)', 
            description: 'تزریق اسکریپت چت آنلاین (مثل Tawk.to) به صفحات.', 
            version: '2.0.1', 
            author: 'Integration', 
            isActive: false, 
            icon: 'MessageCircle' 
        },
        { 
            id: 'maintenance_mode', 
            name: 'Maintenance Mode', 
            description: 'نمایش بنر تعمیرات.', 
            version: '1.0.0', 
            author: 'System', 
            isActive: false, 
            icon: 'AlertTriangle' 
        },
        { 
            id: 'analytics', 
            name: 'Google Analytics', 
            description: 'فعال‌سازی رهگیری ترافیک واقعی.', 
            version: '3.4.1', 
            author: 'Google', 
            isActive: true, 
            icon: 'BarChart' 
        }
    ]
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  
  // Real User State
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  // Configuration persistence
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
      const saved = localStorage.getItem('pandenik_config');
      return saved ? JSON.parse(saved) : INITIAL_CONFIG;
  });

  const [language, setLanguage] = useState<Language>('fa');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [firebaseError, setFirebaseError] = useState('');

  // GLOBAL STATE FOR CONTENT (Shared between Admin & User Views)
  const [allIdeas, setAllIdeas] = useState<IdeaPost[]>(() => generateRealContent());
  const [allChallenges, setAllChallenges] = useState<Challenge[]>(MOCK_CHALLENGES_DATA);

  // 1. Check Auth State on Boot
  useEffect(() => {
    if (isFirebaseConfigured() && auth) {
        // Use modular syntax: onAuthStateChanged(auth, callback)
        const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
            if (firebaseUser) {
                // User is signed in
                const userData: User = {
                    ...MOCK_USER_TEMPLATE,
                    id: firebaseUser.uid,
                    name: firebaseUser.displayName || 'کاربر بدون نام',
                    email: firebaseUser.email || '',
                    avatar: firebaseUser.photoURL || 'https://picsum.photos/200/200',
                    // Check local storage if we saved extra details before, otherwise default
                    ...JSON.parse(localStorage.getItem(`user_details_${firebaseUser.uid}`) || '{}')
                };
                setUser(userData);
            } else {
                setUser(null);
            }
            setIsLoadingAuth(false);
        });
        return () => unsubscribe();
    } else {
        setIsLoadingAuth(false);
    }
  }, []);

  // 2. Persist Config
  useEffect(() => {
      localStorage.setItem('pandenik_config', JSON.stringify(siteConfig));
  }, [siteConfig]);
  
  // 3. Persist User Extra Details (simulating DB for fields Firebase Auth doesn't have)
  useEffect(() => {
      if (user) {
          localStorage.setItem(`user_details_${user.id}`, JSON.stringify(user));
      }
  }, [user]);

  const handleUpdateUser = (updatedUser: User) => {
      setUser(updatedUser);
      // In a real app with Firestore, you would update the document here:
      // updateDoc(doc(db, 'users', updatedUser.id), updatedUser);
  };

  const handleGoogleLogin = async () => {
      if (!isFirebaseConfigured()) {
          setFirebaseError("لطفاً تنظیمات فایربیس را در فایل services/firebase.ts وارد کنید.");
          return;
      }
      try {
          await signInWithPopup(auth, googleProvider);
          setShowAuthModal(false);
      } catch (error: any) {
          console.error("Login Failed", error);
          if (error.code === 'auth/configuration-not-found') {
              setFirebaseError("سرویس احراز هویت گوگل در پروژه فایربیس شما فعال نشده است.");
          } else if (error.code === 'auth/api-key-not-valid.-please-pass-a-valid-api-key.') {
             setFirebaseError("کلید API فایربیس نامعتبر است.");
          } else {
              setFirebaseError(error.message);
          }
      }
  };

  const handlePhoneLogin = () => {
      alert("برای فعال‌سازی ورود پیامکی، باید سرویس پیامک را در پنل ادمین متصل کنید. (فعلاً از گوگل استفاده کنید)");
  };

  const handleLogout = async () => {
      if (isFirebaseConfigured()) {
          await signOut(auth);
      }
      setUser(null);
      setCurrentView(ViewState.HOME);
  };

  const handleJoinChallenge = (id: string) => {
      if (!user) {
          setShowAuthModal(true);
          return;
      }
      const currentParticipations = user.participatingChallengeIds || [];
      let newParticipations;
      
      if (currentParticipations.includes(id)) {
          newParticipations = currentParticipations.filter(cid => cid !== id);
      } else {
          newParticipations = [...currentParticipations, id];
      }
      
      setUser({ ...user, participatingChallengeIds: newParticipations });
  };

  const renderContent = () => {
    switch (currentView) {
      case ViewState.HOME:
        return <Hero onCtaClick={setCurrentView} config={siteConfig} />;
      case ViewState.CHALLENGES:
        return <ChallengeHub 
                    config={siteConfig} 
                    participatingIds={user?.participatingChallengeIds || []}
                    onToggleParticipation={handleJoinChallenge}
               />;
      case ViewState.IDEA_LAB:
        return <IdeaLab 
                    isLoggedIn={!!user} 
                    onLoginReq={() => setShowAuthModal(true)} 
                    config={siteConfig} 
                    externalFeed={allIdeas}
                    setExternalFeed={setAllIdeas}
               />;
      case ViewState.PROFILE:
        return user ? (
            <Profile 
                user={user} 
                config={siteConfig} 
                onUpdateUser={handleUpdateUser} 
                onLogout={handleLogout}
            /> 
        ) : ( 
            <Hero onCtaClick={setCurrentView} config={siteConfig} /> 
        );
      case ViewState.ADMIN_PANEL:
        // Simple security check: In real app, check DB role. Here we check boolean or ID.
        return (user?.isAdmin || user?.role === 'admin') ? 
          <AdminPanel 
            currentConfig={siteConfig} 
            onUpdateConfig={setSiteConfig} 
            allChallenges={allChallenges}
            setAllChallenges={setAllChallenges}
            allIdeas={allIdeas}
            setAllIdeas={setAllIdeas}
          /> : <div className="p-20 text-center text-red-500 font-bold">دسترسی شما به پنل مدیریت محدود شده است.</div>;
      case ViewState.ARTICLES:
          return <Magazine articles={MOCK_ARTICLES} onBack={() => setCurrentView(ViewState.HOME)} />;
      case ViewState.RULES:
      case ViewState.SECURE_PAYMENT:
      case ViewState.CONTACT_US:
      case ViewState.ABOUT_US:
        return <StaticPage view={currentView} />;
      default:
        return <Hero onCtaClick={setCurrentView} config={siteConfig} />;
    }
  };

  if (isLoadingAuth) {
      return <div className="h-screen flex items-center justify-center bg-gray-50">در حال بارگذاری...</div>;
  }

  return (
    <>
      {/* Real Plugins Injection */}
      <SEOHandler currentView={currentView} siteConfig={siteConfig} />
      <PluginInjector config={siteConfig} />

      <Layout 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        user={user}
        language={language}
        setLanguage={setLanguage}
        onLoginClick={() => setShowAuthModal(true)}
        siteConfig={siteConfig}
      >
        {/* Development Helper: Only show if NOT configured properly or for testing */}
        {!isFirebaseConfigured() && (
             <div className="fixed bottom-0 left-0 w-full bg-red-600 text-white text-center text-sm py-2 z-[100] flex justify-center items-center gap-4 shadow-lg">
                 <span>
                    توجه: تنظیمات فایربیس انجام نشده است. برای استفاده واقعی، فایل <code>services/firebase.ts</code> را ویرایش کنید.
                 </span>
                 <button onClick={() => {
                     // Temporary mock login for development if Firebase is missing
                     const mock = {...MOCK_USER_TEMPLATE, isAdmin: true, role: 'admin'};
                     setUser(mock);
                 }} className="bg-white text-red-600 px-3 py-1 rounded font-bold hover:bg-red-50 transition-colors">
                     ورود آزمایشی (Mock)
                 </button>
             </div>
        )}
        
        {/* Admin Quick Toggle (Only for Real Admins in Production) */}
        {user && user.isAdmin && isFirebaseConfigured() && (
             <div className="fixed bottom-4 left-4 z-50">
                 <button onClick={handleLogout} className="bg-gray-800 text-white px-3 py-1 rounded text-xs shadow hover:bg-gray-700">خروج امن</button>
             </div>
        )}

        {renderContent()}
      </Layout>

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-fade-in relative">
                <button onClick={() => setShowAuthModal(false)} className="absolute top-4 left-4 text-gray-400 hover:text-gray-900"><X size={20}/></button>
                
                <div className="p-8 text-center">
                    <h2 className="text-2xl font-bold mb-2">ورود به پندنیک</h2>
                    <p className="text-gray-500 text-sm mb-6">برای ثبت ایده و شرکت در چالش‌ها وارد شوید</p>
                    
                    {firebaseError && (
                        <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4 flex items-center gap-2 text-right">
                            <AlertTriangle size={20} className="flex-shrink-0"/> 
                            <span>{firebaseError}</span>
                        </div>
                    )}

                    <div className="space-y-4">
                        <button onClick={handleGoogleLogin} className="w-full py-3 border rounded-xl flex items-center justify-center gap-2 hover:bg-gray-50 font-medium transition-colors">
                            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5" alt="Google"/>
                            ورود با حساب گوگل
                        </button>
                        <button onClick={handlePhoneLogin} className="w-full py-3 bg-gray-900 text-white rounded-xl hover:bg-gray-800 font-medium opacity-80 cursor-not-allowed">
                            ورود با شماره موبایل (به زودی)
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}
    </>
  );
};

export default App;